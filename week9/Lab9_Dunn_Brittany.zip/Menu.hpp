/*************************************************************************
 * Program Name: Menu.hpp
 * Author: Brittany Dunn
 * Date: June 3 2018
 * Description: This is the header file for the menu functions
 *************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

void displayMenu();
void menuChoice(int);

#endif
