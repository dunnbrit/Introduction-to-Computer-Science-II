/*************************************************************************
 * Program Name: Menu.cpp
 * Author: Brittany Dunn
 * Date: June 3 2018
 * Description: This is the implementation file for the menu functions
 *************************************************************************/
#include <iostream>
#include <string>
#include "Menu.hpp"
#include "Functions.hpp"
#include "getInt.hpp"

using std::string;
using std::cin;
using std::cout;
using std::endl;

//This fucntion displays the main menu
void displayMenu()
{
	cout << "Please choose from the menu options below: " << endl;
	cout << "1. Test the buffer" << endl;
	cout << "2. Create a palindrome" << endl;
	cout << "3. Exit program" << endl;
	cout << "Please enter the number of your choice." << endl;
}

//This function takes the user's choice to procced to the next action
void menuChoice(int choice)
{
	switch(choice)
	{
		case 1:
		{
			int rounds;
			int end;
			int front;
			int choice;
			string temp1;
			string temp2;

			//Get rounds	
			cout << "How many rounds will be simulated?" << endl; 
			cin >> temp1;
			cin.ignore(100, '\n');
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
			while(choice < 1 || choice > 100)
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice = getInt(temp2);
			}
			rounds = choice;
		
			//Get end percentage
			cout << "What is the percentage chance to put a";
			cout << " randomly generated number at the";
			cout << " end of the buffer?" << endl;
			cin >> temp1;
			cin.ignore(100, '\n');
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}		
			choice = getInt(temp2);
			while(choice < 1 || choice > 100)
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice = getInt(temp2);
			}
			end = choice;

			//Get front percentage
			cout << "What is the percentage chance to take out a";
			cout << " randomly generated number at the";
			cout << " front of the buffer?" << endl;
			cin >> temp1;
			cin.ignore(100, '\n');
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
			while(choice < 1 || choice > 100)
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice = getInt(temp2);
			}
			front = choice;
	
			//Call buffer function
			buffer(rounds,end,front);

			break;
		}
		case 2:
		{
			//Get user's string
			cout << "Please enter a string: " << endl;
			string userInput;
			getline(cin,userInput);
			
			//Call palindrome function
			palindrome(userInput);
			break;
		}
		case 3:
		{		
			break;
		}
	}
}

