/*************************************************************************
 * Program Name: Functions.hpp
 * Author: Brittany Dunn
 * Date: June 3 2018
 * Description: This is the header file for the recursive functions.
 *************************************************************************/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <string>

void buffer(int,int,int);
void palindrome(std::string);

#endif
