/*************************************************************************
 * Program Name: Functions.cpp
 * Author: Brittany Dunn
 * Date: June 3 2018
 * Description: This is the implementation file for the recursive functions
 *************************************************************************/

#include <iostream>
#include "Functions.hpp"
#include <cstdlib>
#include <queue>
#include <stack>
#include <string>

using std::string;
using std::queue;
using std::stack;
using std::cout;
using std::endl;
using std::cin;

//This function simulates a buffer
void buffer(int rounds, int end, int front)
{
	//Create queue
	queue<int> buffer;
	//Varible for random numbers and result
	int N;
	int outcomeA;
	int outcomeR;
	double average;
	int length;
	double averageLength;

	for(int i = 1; i <= rounds; ++i) 
	{
		cout << "Round " << i << ": " << endl;

		//Generate random numbers
		N = rand() % 1000 + 1;
		outcomeA = rand() % 100 + 1;
		outcomeR = rand() % 100 + 1;

		//Append number if outcome is less than or equal to end
		if(outcomeA <= end)
		{
			buffer.push(N);
		}

		//Remove number if outcome is less than or equal to front
		if(outcomeR <= front)
		{
			if(!buffer.empty())
			{
				buffer.pop();
			}
		}
		
		//Display values in buffer
		cout << "Current buffer: ";
		if(!buffer.empty())
		{
			queue<int> temp = buffer;
			while(!temp.empty())
			{
				cout << temp.front() << " ";
				temp.pop();
			}
		}
		cout << endl;
		//Display length of buffer
		cout << "Length of buffer: ";
		length = buffer.size();
		cout << length << endl;

		//Display average lengh
		cout << "Average Length: ";
		averageLength = (averageLength * (i - 1) + length)/i;
		cout << averageLength;  
		cout << endl;
	}
	
}

//This fucntion produces a palidrome of the user's string
void palindrome(string input)
{
	//Create stack
	stack<char> userString;
	
	//Add letters to stack and print
	for(int i = 0; i < input.length(); ++i)
	{
		cout << input[i];
		userString.push(input[i]);
	}
	//Remove letters from stack and print
	while(!userString.empty())
	{
		cout << userString.top();
		userString.pop();
	}
	cout << endl;
}
