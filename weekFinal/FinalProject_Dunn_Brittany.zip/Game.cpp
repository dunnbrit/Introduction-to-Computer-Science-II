/*************************************************************************
 * Program Name: Game.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the implementation file for the derived class Game
 *************************************************************************/

#include "Game.hpp"
#include "getInt.hpp"
#include <iostream>
#include <cstdlib> 

using std::cin;
using std::cout;
using std::endl;

//This is the constructor for the game space
Game::Game()
{
	top = nullptr;
	left = nullptr;
	bottom = nullptr;
	right = nullptr;
	next = nullptr;
	type = '?';
}

//This function displays the menu and get choice when the space is landed on
void Game::menu(int* bag)
{
	cout << "You landed on a Game space!" << endl;
	cout << "Here you have a chance to win coins by selecting a box!";
	cout << endl;
	cout << "BUT you can also lose coins if you choose the wrong box!";
	cout << endl;
	cout << "You currently have " << bag[5] << " coins." << endl;
	cout << "Would you like to play the game?" << endl;
	cout << "1.Yes" << endl;
        cout << "2.No" << endl;
        cout << "Please enter the number of your choice." <<endl;

	int choice = 0;
	string temp1 = "";
	string temp2 = "";

		
	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 2 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}	
	cin.ignore(100, '\n');
	
	//Next action based on choice
	if(choice == 2)
	{
		cout << "You have choosen NOT to play a game this turn" <<endl;
	}
	else
	{
		cout << "Beginning game..." << endl;
		cout << "Choose a box to open:" << endl;
		cout << "[1]  [2]  [3]  [4]" << endl;
		cout << "Enter the number of your box." << endl;

		//Get and validate choice
		cin >> temp1;
        	temp2 = inputValid(temp1);
        	while(temp2 == "invalid")
        	{
                	temp2 = inputInvalid();
        	}
        	choice = getInt(temp2);
        	while(choice < 1 || choice > 4)
        	{
               		temp2 = inputInvalid();
                	while(temp2 == "invalid")
                	{
                        	temp2 = inputInvalid();
                	}
                	choice = getInt(temp2);
       		 }
	        cin.ignore(100, '\n');

		int coins;

		//Get random number from box
		switch(choice)
		{
			//Range -10 to 10
			case 1:
			{
				coins = (rand() % (10 - (-10) + 1) + (-10));
			}
				break;
			//Range 1 to 5
			case 2:		
			{
				coins = rand() % 5 + 1;
			}
				break;
			//Range -25 to 5
			case 3:
			{
				coins = (rand() % (5 - (-25) + 1) + (-25));
			}
				break;
			//Range 10 to 50
			case 4:
			{
				coins = (rand() % (50 - 10 + 1) + 10);
			}
				break;
		}
		cout << "You ";
		if(coins < 1)
		{
			cout << "lost ";
		}
		else
		{
			cout << "won ";
		}
		cout << coins << " coins!" << endl;
		bag[5] += coins;
		cout << "You now have " << bag[5] << " coins." << endl;
	}
}

//This function lets the player choose a direction when there is a split in
//the board
void Game::getDirection(Space* currentSpace)
{
        int choice = 0;
        string temp1 = "";
        string temp2 = "";

        cout << "Would you like to go:" << endl;
        cout << "1. Left?" << endl;
        cout << "2. Up?" << endl;
        cout << "Please enter the number of your choice." << endl;

        //Get and validate choice
        cin >> temp1;
        temp2 = inputValid(temp1);
        while(temp2 == "invalid")
        {
                temp2 = inputInvalid();
        }
        choice = getInt(temp2);
        while(choice < 1 || choice > 5 )
        {
                temp2 = inputInvalid();
                while(temp2 == "invalid")
                {
                        temp2 = inputInvalid();
                }
                choice = getInt(temp2);
        }
        cin.ignore(100, '\n');

        if(choice == 1)
        {
                currentSpace->setNext(currentSpace->getLeft());
        }

        else
        {
                currentSpace->setNext(currentSpace->getTop());
        }
}

