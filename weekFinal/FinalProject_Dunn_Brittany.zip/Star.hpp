/*************************************************************************
 * Program Name: Star.hpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the header file for the derived Space class Star
 *************************************************************************/

#ifndef STAR_HPP
#define STAR_HPP

#include "Space.hpp"

class Star : public Space
{
	public:
		Star();
		void menu(int*) override;
		void getDirection(Space*) override;
};

#endif
