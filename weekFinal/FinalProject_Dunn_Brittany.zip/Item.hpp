/*************************************************************************
 * Program Name: Item.hpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the header file for the derived Space class Item
 *************************************************************************/

#ifndef ITEM_HPP
#define ITEM_HPP

#include "Space.hpp"

class Item : public Space
{
	public:
		Item();
		void menu(int*) override;
		void getDirection(Space*) override;
};

#endif
