/*************************************************************************
 * Program Name: Item.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the implementation file for the derived class Item
 *************************************************************************/

#include "Item.hpp"
#include "getInt.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

//This is the constructor for the item space
Item::Item()
{
	top = nullptr;
	left = nullptr;
	bottom = nullptr;
	right = nullptr;
	next = nullptr;
	type = '!';
}

//This function displays the menu and get choice when the space is landed on
void Item::menu(int* bag)
{
	cout << "You landed on an Item space!" << endl;

	//Check if player has enough coins to buy any items before proceeding

	//If player does not have enough coins
	if(bag[5] < 10)
	{
		cout << "Sorry, you currently do not have enough coins";
		cout << " to purchase any items..." << endl;
	}

	//If player does have enough coins to buy an item
	else
	{	
		//Check if container has space for any mushrooms
		bool choiceEmpty = false;
		bool doubleEmpty = false;
		if(bag[0] == 0 || bag[1] == 0)
		{
			choiceEmpty = true;
		}
		if(bag[2] == 0 || bag[3] == 0)
		{
			doubleEmpty = true;
		}
		//If container does not have space
		if(choiceEmpty == false && doubleEmpty == false)
		{
			cout << "You cannot purchase any mushrooms";
                        cout << " because your bag is full." << endl;
		}
		//If container does have space
		if(choiceEmpty == true || doubleEmpty == true)
		{
			//Get menu based on the avaialablity of the bag
			int menu;
			if(choiceEmpty == true && doubleEmpty == true)
			{
				menu = 1;
			}
			else if(choiceEmpty == true && doubleEmpty == false)
			{
				menu = 2;
			}
			else if(choiceEmpty == false && doubleEmpty == true)
			{
				menu = 3;
			}
		
			//Display menu
			cout << "Welcome to the item shop!Here you can buy ";
			cout << "mushrooms to help you on future turns." <<endl;
			cout << "Here are the descriptions of the mushrooms:";
			cout << endl;
			cout << "Choice mushrooms allow you to choose a die ";
			cout << "roll between 1 and 10." << endl;
			cout << "Double mushrooms allow you to roll up to 20.";
			cout << endl;
			cout << "Each mushroom costs 10 coins" << endl;
			cout << "You currently have " <<bag[5] << " coins.";
			cout << endl; 
			switch(menu)
			{
			case 1:
			{
				cout << "Would you like to buy a mushroom?";
				cout << endl;
				cout << "1.Yes - buy a ohoice mushroom"<<endl;
				cout << "2.Yes - buy a double mushroom"<<endl;
				cout << "3.No" << endl;
			}
				break;
			case 2:
			{
				cout << "Would you like to buy a choice";
				cout << " mushroom?" << endl;
				cout << "1.Yes" << endl;
				cout << "2.No" << endl;
			}	
				break;
			case 3:
			{		
				cout << "Would you like to buy a double";
				cout << " mushroom?" << endl;
				cout << "1.Yes" << endl;
				cout << "2.No" << endl;
			}
				break;
			}

			int choice = 0;
			string temp1 = "";
        		string temp2 = "";
		
			//Get and validate choice
			cin >> temp1;
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
		
			//If menu 1 then must be between 1-3
			if(menu == 1)
			{
				while(choice < 1 || choice > 3 )
				{
					temp2 = inputInvalid();
					while(temp2 == "invalid")
					{
						temp2 = inputInvalid();
					}
					choice = getInt(temp2);
				}
			}
		
			//If menu 2 or 3 must be between 1-2
			if(menu == 2 || menu == 3)
			{
				while(choice < 1 || choice > 2 )
				{
					temp2 = inputInvalid();
					while(temp2 == "invalid")
					{
						temp2 = inputInvalid();
					}
					choice = getInt(temp2);
				}
			}
		cin.ignore(100, '\n');

		//Perform next action based on choice and menu
		switch(menu)
		{
			case 1:
			{
				if(choice == 1)
				{
					//Add choice mushroom to bag
					if(bag[0] == 0)
					{
						bag[0] = 1;
					}
					else
					{
						bag[1] = 1;
					}
					//subtract coins
					bag[5] -= 10;
					cout << "You bought a choice mushroom!";					cout << endl;
					cout << " You now have " << bag[5];
					cout << " coins." << endl;
				}
				if(choice == 2)
				{
					//Add double mushroom to bag
					if(bag[2] == 0)
					{
						bag[2] = 1;
					}
					else
					{
						bag[3] = 1;
					}
					//subtract coins
					bag[5] -= 10;
					cout << "You bought a double mushroom!";					cout << endl;
					cout << " You now have " << bag[5];
                                        cout << " coins." << endl;
				}
				if(choice == 3)
				{
					cout << "You did NOT buy a mushroom.";
					cout << endl;
				}
			}
				break;
			case 2:
			{
				if(choice == 1)
                                {
					//Add choice mushroom to bag
					if(bag[0] == 0)
                                        {
                                                bag[0] = 1;
                                        }
                                        else
                                        {
                                                bag[1] = 1;
                                        }
					//subtract coins
					bag[5] -= 10;
                                        cout << "You bought a choice mushroom!";                                        cout << endl;
					cout << " You now have " << bag[5];
                                        cout << " coins." << endl;
				}
				else
				{	
					cout << "You did NOT buy a mushroom.";
                                        cout << endl;
				}
			}
				break;
			case 3:
			{
				if(choice == 1)
				{
					//Add double mushroom to bag
					if(bag[2] == 0)
                                        {
                                                bag[2] = 1;
                                        }
                                        else
                                        {
                                                bag[3] = 1;
                                        }
					//subtract coins
					bag[5] -= 10;
					cout << "You bought a double mushroom!";                                        cout << endl;
					cout << " You now have " << bag[5];
                                        cout << " coins." << endl;
				}
				else
				{
                                        cout << "You did NOT buy a mushroom.";
                                        cout << endl;
                                }
                        }
                                break;
		}	
	}
	}
}

//This function gives the user a choice of direction when at certain space
void Item::getDirection(Space* currentSpace)
{
	int choice = 0;
	string temp1 = "";
        string temp2 = "";
	
	cout << "Would you like to go:" << endl;
	cout << "1. Right?" << endl;
	cout << "2. Up?" << endl;
	cout << "Please enter the number of your choice." << endl;
	
	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 5 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	cin.ignore(100, '\n');

	if(choice == 1)
	{
		currentSpace->setNext(currentSpace->getRight());
	}	

	else
	{
		currentSpace->setNext(currentSpace->getTop());
	}
}










