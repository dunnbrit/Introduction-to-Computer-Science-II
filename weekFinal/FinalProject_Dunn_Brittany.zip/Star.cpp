/*************************************************************************
 * Program Name: Star.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the implementation file for the derived class Star
 *************************************************************************/

#include "Star.hpp"
#include "getInt.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

//This is the constructor for the star space
Star::Star()
{
	top = nullptr;
	left = nullptr;
	bottom = nullptr;
	right = nullptr;
	next = nullptr;
	type = '*';
}

//This function displays the menu and get choice when the space is landed on
void Star::menu(int* bag)
{
	cout << "You landed on a Star space!" << endl;

	//Check if player has enough coins to buy start before proceeding

	//If player does not have enough coins
	if(bag[5] < 20)
	{
		cout << "Sorry, you currently do not have enough coins";
		cout << " to purchase a Star..." << endl;
	}

	//If player does have enough coins to buy a star
	else
	{	
		int choice = 0;
		string temp1 = "";
        	string temp2 = "";

		//Display menu
		cout << "You currently have " << bag[4] << " stars";
		cout << " and " << bag[5] << " coins." << endl;
		cout << "Would you like to purchase a star for 20 coins?";
		cout << endl;
		cout << "1.Yes" << endl;
		cout << "2.No" << endl;
		cout << "Please enter the number of your choice." <<endl;
	
		//Get and validate choice
		cin >> temp1;
		temp2 = inputValid(temp1);
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
		while(choice < 1 || choice > 2 )
		{
			temp2 = inputInvalid();
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
		}	
		cin.ignore(100, '\n');
	
		//Next action based on choice
		switch(choice)
		{
			case 1:
			{
				//subtract 20 coins
				bag[5] -= 20; 
	
				//add 1 star
				bag[4] += 1;
				
				cout << "You bought a star!" << endl;
			}
				break;
			case 2:
			{
				cout << "You did NOT buy a star." << endl;
			}
				break;
		}
	}
}
			
//This function sets the next direction when next is set to nullptr
void Star::getDirection(Space* currentSpace)
{
	//Last space so leave set to null
}
















