/*************************************************************************
 * Program Name: DoublyList.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the implementation file for the class DoublyList
 *************************************************************************/

#include "DoublyList.hpp"
#include "Space.hpp"
#include <iostream>
#include <iomanip>

using std::cout;
using std::endl;
using std::setw;
//This is the constructor for DoublyList
DoublyList::DoublyList()
{
	head = nullptr;
	tail = nullptr;
	current = nullptr;
}

//This function prints the doubly list
void DoublyList::printBoard(Space** abcBoard, Space** dBoard, Space** mBoard, Space** kBoard )
{
	char tempType = current->getType();
	current->setType( 'O');
	 
	for(int i = 25; i > 12 ; --i)
        {
                cout << "        ";
                cout << abcBoard[i]->getType() << endl;
        }
	cout << mBoard[3]->getType() << " " << mBoard[2]->getType()  << " ";
	cout << mBoard[1]->getType()  << " " << mBoard[0]->getType()  << " ";
	cout << abcBoard[12]->getType()  << " " << kBoard[8]->getType()  << " ";
	cout << kBoard[7]->getType()  << " " << kBoard[6]->getType()  << " ";
	cout << kBoard[5]->getType()  << " " <<endl;
	
	cout << mBoard[4]->getType()  << "       " << abcBoard[11]->getType();
	cout  << "       " << kBoard[4]->getType()  << endl;

	cout << mBoard[5]->getType() << " " << mBoard[6]->getType()  << " ";
        cout << mBoard[7]->getType()  << " " << mBoard[8]->getType()  << " ";
        cout << abcBoard[10]->getType()  << " " << kBoard[0]->getType()  << " ";
        cout << kBoard[1]->getType()  << " " << kBoard[2]->getType()  << " ";
        cout << kBoard[3]->getType()  << " " <<endl;

	for(int i = 9; i > 6 ; --i)
	{
		cout << "        ";
		cout << abcBoard[i]->getType() << endl;
	}

	cout << dBoard[5]->getType() << " " << dBoard[6]->getType()  << " ";
        cout << dBoard[7]->getType()  << " " << dBoard[8]->getType()  << " ";
        cout << abcBoard[5]->getType() << endl;  

	cout << dBoard[4]->getType()  << "       " << abcBoard[4]->getType();
        cout << endl;

	cout << dBoard[3]->getType() << " " << dBoard[2]->getType()  << " ";
        cout << dBoard[1]->getType()  << " " << dBoard[0]->getType()  << " ";
        cout << abcBoard[3]->getType() << endl;  

	for(int i = 2; i > -1 ; --i)
        {
                cout << "        ";
                cout << abcBoard[i]->getType() << endl;
        }

	current->setType(tempType);

}
//This function sets the tail of the list
void DoublyList::setTail(Space* t)
{
	tail = t;
}

//This function sets the head of the list
void DoublyList::setHead(Space* h)
{
	head = h;
}

//This function sets the current space of player
void DoublyList::setCurrent(Space* c)
{
	current = c;
}

//This function returns the tail
Space* DoublyList::getTail()
{
	return tail;
}

//This function returns the current
Space* DoublyList::getCurrent()
{
	return current;
}
