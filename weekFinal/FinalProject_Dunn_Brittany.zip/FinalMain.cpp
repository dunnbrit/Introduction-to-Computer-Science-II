/*************************************************************************
 * Program Name: FinalMain.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description:
 *************************************************************************/

#include <iostream>
#include <cstdlib>
#include "Menu.hpp"
#include "getInt.hpp"
#include "Space.hpp"
#include "DoublyList.hpp"
#include "Star.hpp"
#include "Item.hpp"
#include "Game.hpp"

using std::cout;
using std::cin;
using std::endl;


int main()
{
	//Create container
	int container[5];
	//Holds choice mushrooms
	container[0] = 0;
	container[1] = 0;
	//Holds double mushrooms
	container[2] = 0;
	container[3] = 0;
	//Holds stars
	container[4] = 0;
	//Holds coins
	container[5] = 20;

	//Create board
	DoublyList board;
	//Create arrays for board portions
	Space* abc[26];
	Space* subD[9];
	Space* subM[9];
	Space* subT[10];
	Space* subK[9];

	//Fill board portion abc with spaces
	for(int i = 0; i < 26; ++i)
	{
		//Create game space because of direction choice
		if(i == 12)
		{
			abc[i] = new Game;
		}
		//Create star space
		else if(i == 25)
		{
			abc[i] = new Star;
		}
		//Create item spaces
		else if(i % 2 == 0)
		{
			abc[i] = new Item;
		}
		//Create game spaces
		else
		{
			abc[i] = new Game;
		}
	}
	//Set abc board spaces pointers
	//set top and next
	for(int i = 0; i < 25; ++i)
	{
		abc[i]->setNext(abc[i+1]);
		abc[i]->setTop(abc[i+1]);
	}
	//set bottom
	for(int i = 1; i < 26; ++i)
	{
		abc[i]->setBottom(abc[i-1]);
	} 

	//Fill board subportion D ,M, and K with spaces
	for(int i = 0; i < 9; ++i)
	{
		//Create star space
		if(i == 7)
                {
                        subD[i] = new Star;
                	subM[i] = new Star;
			subK[i] = new Star;

		}
		//Create item spaces
		else if(i % 2 == 0)
                {
                        subD[i] = new Item;
                	subM[i] = new Item;
			subK[i] = new Item;
		}
		//Create game spaces
		else
                {
                        subD[i] = new Game;
                	subM[i] = new Game;
			subK[i] = new Game;
		}
	}

	//Set sudD board spaces pointers
	//set next,left and right or top and bottom
	for(int i = 0; i < 9; ++i)
        {
		if(i == 0)
		{
			subD[i]->setLeft(subD[i+1]);
			subM[i]->setLeft(subM[i+1]);
			subK[i]->setLeft(abc[10]);

			subD[i]->setRight(abc[3]);
			subM[i]->setRight(abc[12]);
			subK[i]->setRight(subK[i+1]);
		
			subD[i]->setNext(subD[i+1]);
	                subM[i]->setNext(subM[i+1]);
        	        subK[i]->setNext(subK[i+1]);
		}
		else if(i == 4)
		{
			subD[i]->setTop(subD[i+1]);
			subD[i]->setBottom(subD[i-1]);

			subM[i]->setTop(subM[i+1]);
			subM[i]->setBottom(subM[i-1]);

			subK[i]->setTop(subK[i+1]);
			subK[i]->setBottom(subK[i-1]);
		
			subD[i]->setNext(subD[i+1]);
                        subM[i]->setNext(subM[i+1]);
                        subK[i]->setNext(subK[i+1]);
		}
		else if(i == 8)
		{
			subD[i]->setLeft(subD[i-1]);
                        subM[i]->setLeft(subM[i-1]);
                        subK[i]->setLeft(abc[12]);

                        subD[i]->setRight(abc[5]);
                        subM[i]->setRight(abc[10]);
                        subK[i]->setRight(subK[i-1]);

                        subD[i]->setNext(abc[5]);
                        subM[i]->setNext(abc[10]);
                        subK[i]->setNext(abc[12]);
		}
		else
		{
			subD[i]->setLeft(subD[i+1]);
                        subM[i]->setLeft(subM[i+1]);
			subK[i]->setLeft(subK[i-1]);
			
			subD[i]->setRight(subD[i-1]);
                        subM[i]->setRight(subM[i-1]);
                        subK[i]->setRight(subK[i+1]);
			
			subD[i]->setNext(subD[i+1]);
                        subM[i]->setNext(subM[i+1]);
                        subK[i]->setNext(subK[i+1]);
		}
	}
	//Set main abc portion of board and connect sub portions D,M,K
	abc[3]->setLeft(subD[0]);
	abc[5]->setLeft(subD[8]);
	abc[10]->setLeft(subM[8]);
	abc[12]->setLeft(subM[0]);
	abc[10]->setRight(subK[0]);
	abc[12]->setRight(subK[8]);
	//Set direction spaces
	abc[3]->setNext(nullptr);
	abc[10]->setNext(nullptr);
	abc[12]->setNext(nullptr);

		
	//Play game
	//set start
	board.setHead(abc[0]);
	//set end
	board.setTail(abc[25]);
	//set current
	board.setCurrent(abc[0]);


	//Description
	cout << " Goal: Reach the end of the board with a star before your turns run out. There  are 4 stars scattered throughout the board. You must land on a star space to be able to purchase a star for 20 coins.You will begin the game with 20 coins" <<endl<<endl; 
	cout <<" There are item and mini-game spaces within the board to help you collect stars." << endl; 
	cout << "Item spaces allow you to purchase mushrooms for 10 coins which will give you an advantage when rolling the die in a future turn.You can only carry two of each type of mushroom. There are two types of mushrooms. Mini-game spaces will give you the option to play a mini-game in which you can win or lose coins." << endl << endl;
	cout << " If you reach the end with a star you will win a medal.The medal will depend on how many stars you have collected. If you run out of turns before reaching the end or reach the end without a star you lose." << endl;
  	cout << endl;

	cout << "This is the board: " << endl;

	board.printBoard(abc,subD,subM,subK);

	cout << "Star spaces are represented by * " << endl;
	cout << "Item spaces are represented by ! " << endl;
	cout << "Game spaces are represented by ? " << endl;
	cout << "Your current spaces is represented by ( )" << endl;
	cout << "You are starting with " <<container[5] << " coins." << endl;
	cout << endl;

	//Game Limit: turns
	int turns;
	int choice;
        string temp1;
        string temp2;

	//Get number of turns from user
	cout << "How many turns would you like to play" << endl;
	cout << "1. 10 turns" << endl;
	cout << "2. 15 turns" << endl;
	cout << "3. 20 turns" << endl;

	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 3 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	cin.ignore(100,'\n');
	//Set turns
	switch(choice)
	{
		case 1:
		{
			turns = 10;
		}		
			break;
		case 2: 
		{
			turns = 15;
		}	
			break;
		case 3: 			
		{
			turns = 20;
		}
			break;
	}

	//Start turns
	do
	{
		cout << endl;
		if(turns == 1)
		{
			cout << "Last turn!" << endl;
		}
		else
		{
			cout << turns << " turns remaining." << endl;
		}
		bool items = false;
		//Check if player has any items
		for(int i = 0; i < 4; ++i)
		{
			if(i < 2 && container[i] > 0)
			{	
				cout << "You have a choice mushroom" << endl;
				items = true;
			}
			if(i > 1 && container[i] > 0)
			{
				cout << "You have a double mushroom" << endl;
				items = true;
			}
		}
	
		int roll;

		//If they have an item, check if they want to use it
		if(items == true)
		{
			cout << "Would you like to use one of your mushrooms";
			cout << " this turn?" << endl;
			cout << "1. Yes - use choice mushroom" << endl;
			cout << "2. Yes - use double mushroom" << endl;
			cout << "3. No" << endl;	
				
			cin >> temp1;
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
			while(choice < 1 || choice > 3 )
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice = getInt(temp2);
			}	
			cin.ignore(100,'\n');
			
			switch(choice)
			{
				//Use choice mushroom
				case 1:
				{
					if(container[0] > 0 || container[1] > 0)
					{
						if(container[1] > 0)
						{
							container[1] = 0;
						}	
						else
						{
							container[0] = 0;
						}
						cout << "Using choice mushroom";						cout << "...What is your roll?";
						cout << " (1-10)" <<endl;
						cin >> temp1;
					        temp2 = inputValid(temp1);
    					    	while(temp2 == "invalid")
        					{
              						temp2 = inputInvalid();
       						}
        					choice = getInt(temp2);
        					while(choice < 1 || choice > 10)
        					{
               						 temp2 = inputInvalid();
                					while(temp2 =="invalid")
                					{
                        				temp2 = inputInvalid();
                					}
                					choice = getInt(temp2);
        					}
						cin.ignore(100,'\n');
						roll = choice;
					}
					else
					{
                                                cout << "You do not have a ";
                                                cout << "choice mushroom.";
                                                cout << " Rolling normally";
                                                roll = rand() % 10 + 1;
                                                cout << "... you rolled a ";
                                                cout << roll;
                                                cout << endl;
                                        }

						
				}
					break;
				//Use double mushroom
				case 2:
				{
					if(container[2] > 0)
					{
						cout << "Using double mushroom";
						container[2] = 0;
						roll = rand() % 20 + 1;
						cout << "... you rolled a "; 
						cout << roll;
						cout << endl;
					}
					else if(container[3] > 0)
                                        {
                                                cout << "Using double mushroom";
                                                container[3] = 0;
                                                roll = rand() % 20 + 1;
                                                cout << "... you rolled a ";
                                                cout << roll;
                                                cout << endl;
                                        }
					else
					{
						cout << "You do not have a ";
						cout << "double mushroom.";
						cout << " Rolling normally";
						roll = rand() % 10 + 1;
                                                cout << "... you rolled a ";
                                                cout << roll;
                                                cout << endl;
					}
				}
					break;
				//If not using item then roll normally
				case 3:
				{
					cout << "You choose to not use a";
					cout << " mushroom." << endl; 
					//Roll die	
					roll = rand() % 10 + 1;
					cout << "You rolled a " << roll << endl;
				}
					break;			
			}
		}
		//If they do not have any items roll normally
		else
		{
			//Roll die
			roll = rand() % 10 + 1;
			cout << "You rolled a " << roll << endl;
		}

	for(int i = 0; i < roll; ++i)
	{
		bool direction = false;
		//If a direction space is reached
		if((board.getCurrent())->getNext() == nullptr)
		{
			
			board.getCurrent()-> getDirection(board.getCurrent());
			direction = true;
		}
		
		//Set current space to the next space
		Space* tempSpace = board.getCurrent()->getNext();
		if(tempSpace == nullptr)
		{
			//don't change space and stop advancing
			i = roll;
		}
		else
		{
			//If direction is true reset next to nullptr
			//to stop an endless loop on board
			if(direction == true)
			{
				board.getCurrent()->setNext(nullptr);
				direction = false;
			}
			board.setCurrent(tempSpace);
		}	
	}
	
	//Display board location
	board.printBoard(abc,subD,subM,subK);

	//See what space is landed on and play space
	board.getCurrent()->menu(container);
	
	//Decrease turns
	--turns;
	}
	while(turns != 0 && board.getTail() != board.getCurrent());

	//Check if player won
	if(turns == 0 && board.getCurrent() != board.getTail())
	{
		cout << "Sorry, you lost. You did not reach the end of the";
 		cout << " board by the end of your turns" << endl;
	}
	else if(container[4] == 0)
	{
		cout << "Sorry, you lost. You did not collect a star" << endl;
	}
	else
	{
		cout << "You won! You ended the game with " <<container[5];
		cout << " coins and " << container[4] << " stars." << endl;
		cout << "You earned a ";
		if(container[4] > 3)
		{
			cout << "gold";
		}
		else if(container[4] < 4 && container[4] > 1)
		{
			cout << "silver";
		}
		else if(container[4] < 2)
		{
			cout << "bronze";
		}
		cout << " medal!" << endl;
	}

	return 0;

}
