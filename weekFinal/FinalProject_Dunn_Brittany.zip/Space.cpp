/*************************************************************************
 * Program Name: Space.cpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the implementation file for the class Space
 *************************************************************************/

#include <iostream>
#include "Space.hpp"

//This fucntion sets the left space
void Space::setLeft(Space* l)
{
	left = l;
}

//This fucntion sets the right space
void Space::setRight(Space* r)
{
       right = r;
}

//This fucntion sets the top space
void Space::setTop(Space* t)
{
       top = t;
}

//This fucntion sets the bottom space
void Space::setBottom(Space* b)
{
       bottom = b;
}

//This fucntion sets the next space
void Space::setNext(Space* n)
{
       next = n;
}

//This function sets the type
void Space::setType(char c)
{
	type = c;
}

//This function returns the left space
Space* Space::getLeft()
{
	return left;
}

//This function returns the right space
Space* Space::getRight()
{
	return right;
}

//This function returns the bottom space
Space* Space::getBottom()
{
	return bottom;
}

//This function returns the top space
Space* Space::getTop()
{
	return top;
}

//This function returns the next space
Space* Space::getNext()
{
	return next;
}

//This function returns the type
char Space::getType()
{
	return type;
}

