/*************************************************************************
 * Program Name: Space.hpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the header file for the class Space
 *************************************************************************/

#ifndef SPACE_HPP
#define SPACE_HPP

class Space
{
	protected:
		Space* top;
		Space* right;
		Space* left;
		Space* bottom;
		Space* next;
		char type;
	public:	
		virtual ~Space() = default;
		virtual void menu(int*) = 0;
		virtual void getDirection(Space*) = 0;
		void setTop(Space* t);
		void setLeft(Space* l);
		void setRight(Space* r);
		void setBottom(Space* b);
		void setNext(Space* n);
		void setType(char c);
		Space* getTop();
		Space* getRight();
		Space* getLeft();
		Space* getBottom();
		Space* getNext();
		char getType();
};

#endif


