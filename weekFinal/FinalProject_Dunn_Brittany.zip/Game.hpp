/*************************************************************************
 * Program Name: Game.hpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the header file for the derived Space class Game
 *************************************************************************/

#ifndef GAME_HPP
#define GAME_HPP

#include "Space.hpp"

class Game : public Space
{
	public:
		Game();
		void menu(int*) override;
		void getDirection(Space*) override;
};

#endif
