/*************************************************************************
 * Program Name: DoublyList.hpp
 * Author: Brittany Dunn
 * Date: June 12 2018
 * Description: This is the header file for the class DoublyList
 *************************************************************************/

#ifndef DOUBLYLIST_HPP
#define DOUBLYLIST_HPP

#include "Space.hpp"

class DoublyList
{
	protected:
	Space *head;
	Space *tail;
	Space *current;

	public:
	DoublyList();
	void setTail(Space*);
	void setHead(Space*);
	void setCurrent(Space*);
	void printBoard(Space**, Space**, Space**, Space**);
	Space* getTail();
	Space* getCurrent();
};

#endif	
