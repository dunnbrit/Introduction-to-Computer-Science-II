/*************************************************************************
 * Program Main: LabMain.cpp
 * Author: Brittany Dunn
 * Date: May 13 2018
 * Description: This program displays a menu and lets the user choose 
 * from 7 different functions.
 *************************************************************************/

#include <iostream>
#include <string>
#include "Node.hpp"
#include "Menu.hpp"
#include "getInt.hpp"
#include "DoublyList.hpp"

using std::cout;
using std::string;
using std::cin;
using std::endl;

int main()
{
	int choice;
	string temp1;
	string temp2;
	DoublyList list;
	
	do
	{
	//Display menu
	displayMenu();

	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 8 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}

	//Perform next action based on choice
	menuChoice(choice, &list);
	} 
	while(choice != 8);

	return 0;
}
