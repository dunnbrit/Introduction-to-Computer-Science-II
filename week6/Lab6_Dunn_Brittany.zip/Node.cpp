/*************************************************************************
 * Program Name: Node.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018
 * Description: This is the implementation file for the class Node
 *************************************************************************/

#include "Node.hpp"

//This is the constructor for node
Node::Node(int value, Node* prev1 = nullptr, Node* next1 = nullptr)
{
	val = value;
	prev = prev1;
	next = next1;
}
