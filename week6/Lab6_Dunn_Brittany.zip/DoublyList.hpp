/*************************************************************************
 * Program Name: DoublyList.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018
 * Description: This is the header file for the class DoublyList
 *************************************************************************/

#ifndef DOUBLYLIST_HPP
#define DOUBLYLIST_HPP

#include "Node.hpp"

class DoublyList
{
	protected:
	Node *head;
	Node *tail;

	public:
	DoublyList();
	~DoublyList();
	//Function 1
	void addHeadNode(int);
	//Function 2
	void addTailNode(int);
	//Function 3
	void deleteFirstNode();
	//Function 4
	void deleteLastNode();
	//Function 5
	void traverseReverse();
	//Function 6
	void printList();
	//Extra credit functions
	void printHeadNode();
	void printTailNode();

};

#endif	
