/*************************************************************************
 * Program Name: Node.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018
 * Description: This is the header file for the class Node
 *************************************************************************/

#ifndef NODE_HPP
#define NODE_HPP

struct Node
{
	int val;
	Node *next;
	Node *prev;
	Node(int, Node*, Node*);
};

#endif
