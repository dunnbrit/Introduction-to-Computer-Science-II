/*************************************************************************
 * Program Name: Menu.cpp
 * Author: Brittany Dunn
 * Date: May 13 2018
 * Description: This is the implementation file for the menu functions
 *************************************************************************/

#include <iostream>
#include <string>
#include "Menu.hpp"
#include "DoublyList.hpp"
#include "getInt.hpp"

using std::string;
using std::cout;
using std::endl;
using std::cin;


//This function displays the menu
void displayMenu()
{
	cout << "\nPlease choose an option from the list below: " <<endl;
	cout << "1. Add a new node to the head" <<endl;
	cout << "2. Add a new node to the tail" <<endl;
	cout << "3. Delete the first node" <<endl;
	cout << "4. Delete the last node" <<endl;
	cout << "5. Traverse the list reversely" <<endl;
	cout << "6. Display value of head node" <<endl;
	cout << "7. Display value of tail node" <<endl;
	cout << "8. Exit" <<endl;
	cout << "Please enter the number of your choice." <<endl;
}

//This function takes the users choice and determines next action
void menuChoice(int choice, DoublyList* list)
{
	int number;
	string temp1;	
	string temp2;

	switch(choice)
	{
		case 1:
		{
			//Prompt user to enter number
			cout << "Please enter a number: " << endl;
			//Get number and validate input
			cin.ignore();
			cin >> temp1;
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			number = getInt(temp2); 
			//Call function to add to head of list
			list->addHeadNode(number);
			//Print list
			list->printList();
		}
			break;
		case 2:
		{
			//Prompt user to enter number
			cout << "Please enter a number: " << endl;
			//Get number and validate input
			cin.ignore();
			cin >> temp1;
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			number = getInt(temp2);
			//Call function to add node to tail of list
			list->addTailNode(number);
			//Print list
			list->printList();
		}
			break;
		case 3:
		{
			//Call function to delete first node
			list->deleteFirstNode();
			//Print list
			list->printList();
		}
			break;
		case 4:
		{
			//Call function to delete last node
			list->deleteLastNode();
			//Print list
			list->printList();
		}
			break;
		case 5:
		{
			//Call function to print list in reverse
			list->traverseReverse();
		}
			break;
		case 6:
		{
			//Call function to print head node value
			list->printHeadNode();
		}
			break;
		case 7:
		{
			//Call function to print tail node value
			list->printTailNode();
		}
			break;
		case 8:
			break;
	}
}
			
