/**********************************************************************
 * Program Name: matrix.hpp
 * Author: Brittany Dunn
 * Date: April 8 2018
 * Description: This is the header file for the function readMartix.
 **********************************************************************/

#ifndef MATRIX_HPP
#define MATRIX_HPP

//Function prototype for readMatrix
//Accepts a poitner to a 2D array and an int as parameters
void readMatrix(int**,int);

#endif

