/**********************************************************************
 * Program Name: determinant.cpp
 * Author: Brittany Dunn
 * Date: April 8 2018
 * Description: This is the header file for the function determinnant.
 **********************************************************************/

#include "determinant.hpp"

/**********************************************************************
 * int determinant(int**, int)
 * This function accepts a pointer to a 2D array and an integer as 
 * parameters. It uses the integer to determine the size of the 2D 
 * array to decide which equation to use to calculate the determinant.
 * Then it uses the values stored in the 2D array to calculate the
 * determinant. The determinant is returned.
 **********************************************************************/

int determinant(int** matrix, int size)
{
	//Varible which will store the calculated determinant
	int determinant;

	//Calculate determinant based on size of matrix

	//If matrix 2x2
	if(size == 4)
	{
		determinant = 
		(matrix[0][0]*matrix[1][1])-(matrix[0][1]*matrix[1][0]);
	}
	//If matrix 3x3
	else
	{
		determinant =
		(matrix[0][0]*
		((matrix[1][1]*matrix[2][2])-(matrix[1][2]*matrix[2][1])))
		-(matrix[0][1]*
		((matrix[1][0]*matrix[2][2])-(matrix[1][2]*matrix[2][0])))
		+(matrix[0][2]*
		((matrix[1][0]*matrix[2][1])-(matrix[1][1]*matrix[2][0])));
	}

	return determinant;
}
