/**********************************************************************
 * Program Name: matrixMain.cpp
 * Author: Brittany Dunn
 * Date: Arpil 8 2018
 * Description: This program prompts the user to choose between a
 * matrix size of 2x2 or 3x3. After the user inputs their chocie the
 * program dynamatically allocates memory for a 2D array which will be 
 * used to store values entered by the user to fill a matrix. The user 
 * is then prompted to enter a value for each spot within the matrix.
 * The program then uses the entered information to calculate the
 * determinant. The determinant and matrix are displayed on the console.
 * Then the dynamatically allocated memory is freed.
 **********************************************************************/ 
#include <iostream>
#include "matrix.hpp"
#include "determinant.hpp"

using std::cout;
using std::cin;
using std::endl;

int main()
{
	//Varibles used to dynamtically allocate memory 
	int size = 0;
	int row = 0;
	int column = 0;

	// Prompt user for size of matrix
	cout << "Please enter 4 for a 2x2 matrix \n";
	cout << "or enter 9 for a 3x3 matrix." << endl;
	//Store user input in size
	cin >> size;

	//Dynamtically allocate memory based on user selection of array size
	//For a 2x2 matrix
	if(size == 4)
	{
		row = 2;
		column = 2;
	}
	//For a 3x3 matrix
	else
	{
		row = 3;
		column = 3;
	}
	//Use for loops to dynamatic allocate memory for a 2D array
	int **array = new int*[row];
	{
		for(int i = 0; i < row; ++i)
		{	
			array[i] = new int[column];
		}	
	}
	
	//Call readMatrix function for user to input values into matrix
	readMatrix(array, size);

	//Call determinant function to calculate the determinant
	int answer = determinant(array, size);

	//Display the determinant
	cout << "The determinant is " << answer << endl;

	//Display the matrix
	for(int x = 0; x < row; ++x)
	{	
		for(int y = 0; y < column; ++y)
		{
			cout << array[x][y] << " ";
		} 
		cout << endl;
	}

	//Free dynamatically allocated memory 
	for(int i = 0; i < row; ++i)
	{
		delete [] array[i];
	}
	delete [] array;
	row = 0;
	column = 0;
	array = NULL;

	return 0;
}
