/**********************************************************************
 * Program Name: matrix.cpp
 * Author: Brittany Dunn
 * Date: April 8 2018
 * Description: This is the implementation file for the function 
 * readMatrix.
 **********************************************************************/
#include <iostream>
#include "matrix.hpp"

using std::cout;
using std::cin;
using std::endl;
/**********************************************************************
 * void readMatrix(int**,int)
 * This function accepts a pointer to a 2D array of integers and an 
 * integer as parameters. The integer is used to determine the size of
 * the matrix and the number of integers the user will need to input.
 * The user's input of integers will be stored in the 2D array that 
 * was a parameter.
 **********************************************************************/
void readMatrix(int** matrix,int size)
{
	//Holds value user inputs
	int value = 0;
	//Used in for loop to control iterations
	int loops = 0;
	
	//Based on the size of the matrix, change the number of loops
	//needed so all user entered values can be stored in matrix
	
	//matrix is 2x2
	if(size == 4)
	{
		loops = 1;
	}
	//matrix is 3x3
	else
	{
		loops = 2;
	}

	//For loop to prompt user for values within the matrix and to 
	//store the values in the 2D array
	for(int row = 0; row <= loops; ++row)
	{
		for(int column = 0; column <= loops; ++column)	
		{	
			cout << "Please enter a value for matrix space: row "; 
			cout << row;
			cout << " column " << column << "." << endl;
			cin >> value;
			matrix[row][column] = value;
		}
	}
}
	

		
