/**********************************************************************
 * Program Name: determinant.hpp
 * Author: Brittany Dunn
 * Date: April 8 2018
 * Description: This is the header file for the function determinant.
 **********************************************************************/

#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

//Function prototype
//Accepts a pointer to a 2D array and an int as parameters
int determinant(int**,int);

#endif

