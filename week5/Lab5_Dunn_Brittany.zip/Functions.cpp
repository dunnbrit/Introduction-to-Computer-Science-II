/*************************************************************************
 * Program Name: Functions.cpp
 * Author: Brittany Dunn
 * Date: May 6 2018
 * Description: This is the implementation file for the recursive functions
 *************************************************************************/

#include <iostream>
#include <string>
#include "Functions.hpp"

using std::string;
using std::cout;
using std::endl;
using std::cin;

//This function prints the reverse of the string it recieves as a parameter
void reverseString(string input)
{
	if(input.length() <= 1)
	{
		cout << input << "\n";
	}
	else
	{
		int i = input.length();
		cout << input[i-1];
		input.erase((i-1),1);
		reverseString(input);
	}
}	

//This function returns the sum of an array
int sumArray(int* array, int elements)
{

		if(elements == 0)
		{
			return 0;
		}
		else
		{
			return array[elements -1] + sumArray(array,elements-1);
		}		
}

//This function returns the triangular number of the int it received
int triangleNumber(int N)
{
	if(N == 0)
	{
		return 0;
	}
	else if(N == 1)
	{
		return 1;
	}
	else
	{
		return N + triangleNumber(N-1);
	}
}

//This function displays the menu
void displayMenu()
{
	cout << "Please choose a function from the list below: " <<endl;
	cout << "1. Print a string in reverse" <<endl;
	cout << "2. Calculate the sum of an array of integers" <<endl;
	cout << "3. Calculate the triangular number of an integer" <<endl;
	cout << "4. Exit program" <<endl;
	cout << "Please enter the number of your choice." <<endl;
}

//This function takes the users choice and determines next action
void menuChoice(int choice)
{
	switch(choice)
	{
		case 1:
		{
			string inputString;
			cout << "Please enter a string." << endl;
			cin.ignore();
			getline(cin,inputString);
			cout << "Your string in reverse: ";
			reverseString(inputString);
		}
			break;
		case 2:
		{
			int elements;
			int number;
			cout << "How many numbers will be in your array?"<<endl;
			cin.ignore();
			cin >> elements;
			//Create array
			int array[elements];
			//Get numbers for array
			for(int i = 0; i < elements; ++i)
			{
				cout << "Please enter a number for your array."<<endl;
				cin.ignore();
				cin >> number;
				array[i] = number;
			}
			//Get sum of array
			cout << "The sum of your array: ";
			cout << sumArray(array,elements) <<endl;
		}
			break;
		case 3:
		{
			int number = 0;
			cout << "Which number would you like the ";
			cout << "triangular number of?" <<endl;
			cin.ignore();
			cin >> number;
			cout << "The triangular number is: ";
			cout << triangleNumber(number) << endl;
		}
			break;
		case 4:
			break;
	}
}
			
