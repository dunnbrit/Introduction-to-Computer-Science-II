/*************************************************************************
 * Program Name: Functions.hpp
 * Author: Brittany Dunn
 * Date: May 6 2018
 * Description: This is the header file for the recursive functions.
 *************************************************************************/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <string>

void reverseString(std::string input);
int sumArray(int* array, int elements);
int triangleNumber(int N);
void displayMenu();
void menuChoice(int choice);

#endif
