/*************************************************************************
 * Program Name: Universe.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is header file for the class Universe
 *************************************************************************/

#ifndef UNIVERSE_HPP
#define UNIVERSE_HPP

#include <memory>
#include "Character.hpp"
#include "Queue.hpp"

class Universe
{
	private:
		Queue* TeamA;
		Queue* TeamB; 		
		int teamA_points;
		int teamB_points;
		Queue* Losers;
	public:
		Universe(Queue* a,Queue* b, Queue* l);
		void firstRoundResults();
		void secondRoundResults();
		bool gameOver();
		bool battlesComplete();
		void displayLosers();
		void displayResults();
};

#endif 
