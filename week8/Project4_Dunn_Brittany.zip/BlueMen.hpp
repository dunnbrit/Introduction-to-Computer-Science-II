/*************************************************************************
 * Program Name: BlueMen.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the derived class BlueMen
 *************************************************************************/

#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP

#include "Character.hpp"
#include <iostream>

class BlueMen : public Character
{
	public:
		BlueMen(std::string n);
		int attack() override;
		int defend(int) override;
};

#endif
