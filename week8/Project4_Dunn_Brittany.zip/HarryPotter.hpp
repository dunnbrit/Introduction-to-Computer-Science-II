/*************************************************************************
 * Program Name: HarryPotter.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the derived class Harry Potter
 *************************************************************************/

#ifndef HARYYPOTTTER_HPP
#define HARRYPOTTER_HPP

#include "Character.hpp"
#include <iostream>

class HarryPotter : public Character
{
	private:
		int lives;
	public:
		HarryPotter(std::string n);
		int attack() override;
		int defend(int) override;
};

#endif
