/*************************************************************************
 * Program Name: QueueNode.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the struct QueueNode
 *************************************************************************/

#ifndef QUEUENODE_HPP
#define QUEUENODE_HPP

#include "Character.hpp"
#include <memory>

struct QueueNode
{
	Character* val;
	QueueNode *next;
	QueueNode *prev;
	QueueNode(Character*, QueueNode*, QueueNode*);
};

#endif
