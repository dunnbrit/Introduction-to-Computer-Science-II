/*************************************************************************
 * Program Name: Universe.cpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the implementation file for the class Universe
 *************************************************************************/

#include <iostream>
#include <string>
#include <memory>
#include "Universe.hpp"
#include "Character.hpp"
#include "Queue.hpp"

using std::cout;
using std::endl;
using std::string;
using std::shared_ptr;

//This is the constructor for the class Universe
Universe::Universe(Queue* a, Queue* b, Queue* l)
{
	TeamA = a;
	TeamB = b;
	Losers = l;
	teamA_points = 0;
	teamB_points = 0;
}

//This function calls the functions and displays the results of the first
//attack/defense
void Universe::firstRoundResults()
{
	int attack = 0;
	int defense = 0;
	int damage = 0;

	//Character A attacks
	attack = (TeamA->head->val)->attack();
	
	//Character B defends
	defense = (TeamB->head->val)->defend(attack);

	//Total damage
	damage = defense - ((TeamB->head->val)->getArmor());
	//Account for possible negative damage because armor
	//if damage is negative make it 0
	if(damage < 0)
	{ 
		damage = 0;
	} 
	
	//Apply damage
	(TeamB->head->val)->applyDamage(damage);
}	

//This function calls the functions and displays the results of the second
//attack/defense
void Universe::secondRoundResults()
{
	int attack = 0;
	int defense = 0;
	int damage = 0;
	
	//Character A attacks
	attack = (TeamB->head->val)->attack();
	
	//Character B defends
	defense = (TeamA->head->val)->defend(attack);
	
	//Total damage
	damage = defense - ((TeamA->head->val)->getArmor());
	//Account for possible negative damage because armor
	//if damage is negative make it 0
	if(damage < 0)
	{
		damage = 0;
	}
	
	//Apply damage
	(TeamA->head->val)->applyDamage(damage);
}

//This function returns true if a character has died
bool Universe::gameOver()
{
	bool game = false;
	if((TeamA->head->val)->getStrength() <= 0)
	{
		game = true;
		//Display battle resluts
		cout << "Team A: " << (TeamA->head->val)->getType();
		cout << " " << (TeamA->head->val)->getName();
		cout << " vs. Team B: " << (TeamB->head->val)->getType();
		cout << " " << (TeamB->head->val)->getName() <<endl;
		cout << " Team B " << (TeamB->head->val)->getType();
		cout << " " << (TeamB->head->val)->getName();
		cout << " won!" << endl;
		//Give team B a point
		++teamB_points;
		//Add team A head character ptr to loser queue
		Losers->addBack(TeamA->getFront());
		//Remove losing character
		TeamA->removeFront();
		//Recover winning character
		TeamB->head->val->recovery();
		//Add winning character to back of queue
		TeamB->addBack(TeamB->getFront());
		//Remove winning character from front of queue
		TeamB->removeFront(); 
	}
	if((TeamB->head->val)->getStrength() <= 0)
	{
		game = true;
		//Display battle resluts
		cout << "Team A: " << (TeamA->head->val)->getType();
		cout << " " << (TeamA->head->val)->getName();
		cout << " vs. Team B: " << (TeamB->head->val)->getType();
		cout << " " << (TeamB->head->val)->getName() <<endl;
		cout << " Team A " << (TeamA->head->val)->getType();
		cout << " " << (TeamA->head->val)->getName();
		cout << " won!" << endl;
		//Give team A a point
		++teamA_points;
		//Add team A head character ptr to loser queue		
		Losers->addBack(TeamB->getFront());
		//Remove losing character
		TeamB->removeFront();
		//Recover winning character
		TeamA->head->val->recovery();
		//Add winning character to back of queue
		TeamA->addBack(TeamA->getFront());
		//Remove winning character from front of queue
		TeamA->removeFront();
	}
	
	return game;
}

//This function returns true if all battles are complete
bool Universe::battlesComplete()
{
	bool battles = false;
	if(TeamA->isEmpty())
	{
		battles = true;
	}
	if(TeamB->isEmpty())
	{
		battles = true;
	}
	return battles;
}

//This function displays the losers queue
void Universe::displayLosers()
{
	Losers->printQueue();
}

//This function displays the final results
void Universe::displayResults()
{
	cout << "Final Results: " << endl;
	cout << "Team A: " << teamA_points << " points" << endl;
	cout << "Team B: " << teamB_points << " points" << endl;
	//If team a won
	if(teamA_points > teamB_points)
	{
		cout << " Team A won!" << endl;
	}
	else if(teamA_points < teamB_points)
	{
		cout << " Team B won!" << endl;
	}
	else
	{
		cout << " Tie Game." << endl;
	}
}


