/*************************************************************************
 * Program Name: GameMain.cpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This program is a combat game between two teams.
 *************************************************************************/

#include <iostream>
#include <string>
#include <memory>

#include "getInt.hpp"
#include "Menu.hpp"
#include "Universe.hpp"
#include "Character.hpp"
#include "Barbarian.hpp"
#include "Vampire.hpp"
#include "BlueMen.hpp"
#include "Medusa.hpp"
#include "HarryPotter.hpp"
#include "Queue.hpp"
#include "QueueNode.hpp"

using std::cout;
using std::cin;
using std::endl;
using std::string;

int main()
{
	//Varibles used to make and validate user choice
	int choice = 0;
	string temp1 = "";
        string temp2 = "";

	//Run game once and then while player has choosen to keep playing
	do
	{
	//Create three Queue objects to use in universe constructor later
	//and to hold character pointers
	Queue teamA;
	Queue teamB;		
	Queue losers;

	//Get number of team fighters from user
	//Team A
	cout << "How many fighters would you like in Team A's lineup?" <<endl;
	cin >> temp1;
	cin.ignore(100,'\n');
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 50 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	int teamAFighters = choice;
	//Team B
	cout << "How many fighters would you like in Team B's lineup?" <<endl;
	cin >> temp1;
	cin.ignore(100,'\n');
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 50 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	int teamBFighters = choice;

	//Get team's lineup of fighters' type and name
	//Team A
	cout << "Choose Team A's lineup." <<endl;
	for(int i = 0; i < teamAFighters; ++i)
	{
		//Prompt user for character
		cout << "Which character would you like for spot ";
		cout << i+1 << " of your lineup?" << endl;
		
		//Display character choice menu
		//Get character
		displayCharacterMenu();

		//Get and validate choice
		cin >> temp1;
		cin.ignore(100,'\n');
		temp2 = inputValid(temp1);
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
		while(choice < 1 || choice > 5 )
		{
			temp2 = inputInvalid();
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
		}
		cout << "Please enter a name for your character: " <<endl;
		string name;
		getline(cin,name);

		//Create character object and place in Team A queue
		teamA.addBack(characterChoice(choice,name));
	}
	//Team B
	cout << "Choose Team B's lineup." <<endl;
	for(int i = 0; i < teamBFighters; ++i)
	{
		//Prompt user for character
		cout << "Which character would you like for spot ";
		cout << i+1 << " of your lineup?" << endl;

		//Display character choice menu
		//Get character
		displayCharacterMenu();

		//Get and validate choice
		cin >> temp1;
		cin.ignore(100,'\n');
		temp2 = inputValid(temp1);
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
		while(choice < 1 || choice > 5 )
		{
			temp2 = inputInvalid();
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
		}
		cout << "Please enter a name for your character: " <<endl;
		string name;
		getline(cin,name);

		//Create character object and place in Team B queue
		teamB.addBack(characterChoice(choice,name));
	}
	//Create universe object
	Universe universe(&teamA, &teamB, &losers);

	//Battle until one team has no fighters left in queue
	bool battle = false;
	do
	{
		bool game = false;
		//Run game until game over
		do
		{	
		//Start Round 1
		universe.firstRoundResults();
		game = universe.gameOver();
		//Check defender is not dead
		if(game == false)
		{
			//Start round 2
			universe.secondRoundResults();
			//Check if defender is dead
			game = universe.gameOver();
		}
	
		}while(game == false);		
		
		battle = universe.battlesComplete();
	}
	while(battle == false);
	
	//Display results
	universe.displayResults();

	//Display option menu for loser pile
	displayLoserMenu();

	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 2 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	if(choice == 1)
	{
		universe.displayLosers();	
	}

	//display end menu
	displayEndMenu();
	
	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 2 )
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}

	}
	while(choice != 2);

	return 0;
}
	

