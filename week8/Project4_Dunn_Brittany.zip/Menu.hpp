/*************************************************************************
 * Program Name: Menu.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the Menu functions
 *************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <memory>
#include "Character.hpp"
#include <iostream>

void displayCharacterMenu();
void displayEndMenu();
Character* characterChoice(int, std::string name);
void displayLoserMenu();
#endif
