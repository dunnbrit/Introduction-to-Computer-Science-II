/*************************************************************************
 * Program Name: Vampire.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the derived class Vampire
 *************************************************************************/

#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP

#include "Character.hpp"
#include <iostream>

class Vampire : public Character
{
	public:
		Vampire(std::string n);
		int attack() override;
		int defend(int) override;
};

#endif
