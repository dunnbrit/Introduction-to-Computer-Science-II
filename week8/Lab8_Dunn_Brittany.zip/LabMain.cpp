/*************************************************************************
 * Program Name: LabMain.cpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This program reads values from files, does a simple
 * search, does a sort, does a binary search.
 *************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <vector> 
#include "Functions.hpp"
#include "getInt.hpp"

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;
using std::vector;

int main()
{
	//Create arrays
	vector<int> noneVector;
	vector<int> earlyVector;
	vector<int> middleVector;
	vector<int> endVector;

	//Read values from the 4 files and store in their arrays
	readFromFile("none.txt",noneVector);
	readFromFile("early.txt",earlyVector);
	readFromFile("middle.txt",middleVector);
	readFromFile("end.txt",endVector);

	//Simple search
	
	//Variables to validate user choice
        int choice;
        string temp1;
        string temp2;

	//Prompt user for value
	cout << "What value would you like to search for?" << endl;

	//Get and validate choice
	cin >> temp1;
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);

	//Search for value in each vector
	search("none.txt",choice,noneVector);
	search("early.txt",choice,earlyVector);
	search("middle.txt",choice,middleVector);
	search("end.txt",choice,endVector);
	cout << endl;

	//Sorting
	
	//Varibles for output file names	
	string noneFile;
	string earlyFile;
	string middleFile;
	string endFile;

	//Sort data from files and output to new files
	noneFile = sort(noneVector);
	earlyFile = sort(earlyVector);
	middleFile = sort(middleVector);
	endFile = sort(endVector);
	cout << endl;

	//Binary search
	
	//Read values from output files from sorting step
	//and store in new vectors
	vector<int> newNoneVector;
        vector<int> newEarlyVector;
        vector<int> newMiddleVector;
        vector<int> newEndVector;

	readFromFile(noneFile,newNoneVector);
        readFromFile(earlyFile,newEarlyVector);
        readFromFile(middleFile,newMiddleVector);
        readFromFile(endFile,newEndVector);
        
	//Prompt user for target value
        cout << "What value would you like to search for?" << endl;
        
	//Get and validate choice	
        cin >> temp1;
        temp2 = inputValid(temp1);
        while(temp2 == "invalid")
        {
                temp2 = inputInvalid();
        }
        choice = getInt(temp2);

	//Search for target value
        binarysearch(noneFile,choice,newNoneVector);
        binarysearch(earlyFile,choice,newEarlyVector);
        binarysearch(middleFile,choice,newMiddleVector);
        binarysearch(endFile,choice,newEndVector);
        cout << endl;

	return 0;
}
