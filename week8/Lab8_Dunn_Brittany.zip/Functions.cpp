/*************************************************************************
 * Program Name: Functions.cpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the implementation file for the functions
 *************************************************************************/

#include "Functions.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;
using std::vector;

//This function reads the values from a file and stores them in an array
void readFromFile(string fileName , vector<int>& vector)
{
	ifstream readFile;

	//Open file
	readFile.open(fileName, std::ios::in);

	//If file cannot be opened exit program
	if(!readFile)
	{
		cout << "Error opening file." << endl;;
	}

	//Read values and store in array
	else
	{
		cout << "Reading values from " << fileName << "..." <<endl;
		
		int value;
	
		while(readFile >> value)
		{
			vector.push_back(value);
		}
				
		cout << "Values stored in array:" << endl;
		for(int i = 0; i < vector.size(); ++i)
		{
			cout << vector[i] << "  ";
		}
		cout << endl;
		cout << endl;

		//Close file
		readFile.close();
	}
}

//This function uses a search algorthim to search for a target value and 
//output if the target was found (adapted from linear search in textbook
//examples)
void search(string fileName, int value, vector<int>& vector)
{
	bool found = false;
	int index = 0;
	
	while(index < vector.size() && !found)
	{
		if(vector[index] == value)
		{
			found = true;
		}
		++index;
	}

	cout << fileName << ": target value";
	if(found == true)
	{
		cout << " found" << endl;
	}
	else
	{
		cout << " not found" << endl;
	}

}	

//This function gets an output file from the user, sorts the values from the
//input file, and outputs the sorted values to the output file while 
//displaying them on the console also 
string sort(std::vector<int>& vector)
{
	string tempFile;
	ofstream outputFile;

	//Prompt user for output file name
	cout << "Please enter the name of the file you would";
	cout << " like the sorted values written." << endl;
	cin >> tempFile;
	
	//Open output file
	outputFile.open(tempFile, std::ios::out);

	//if error opening file
	if(outputFile.fail())
	{
		cout << "Error opening file.";
	}

	//Sort vector(adapted from textbook example vector bubblesort)
	int temp;
	bool swap;
	do
	{
		swap = false;
		for(unsigned count = 0; count < vector.size()-1; ++count)
		{
			if(vector[count] > vector[count+1])
			{
				temp = vector[count];
				vector[count] = vector[count+1];
				vector[count+1] = temp;
				swap = true;
			}
		}
	}
	while(swap);

	//Output sorted vector to file
	int value;
	cout << "Outputting sorted values to " << tempFile << "..." << endl;
	for(int i = 0; i < vector.size(); ++i)
	{
		value = vector[i];
		outputFile << value;
		cout << value;
		outputFile << " ";
		cout << " ";
	}
	cout << endl;

	//Close file
	outputFile.close();

	return tempFile;
}

//This function uses binary search to find a target value within the data
//(adapted from textbook example of binary search
void binarysearch(std::string fileName, int value, std::vector<int>& vector)
{
	int first = 0;
	int last = vector.size()-1;
	int middle;
	bool found = false;  
	
	while(!found && first <= last)
	{
		middle = (first + last) / 2;
		if(vector[middle] == value)
		{
			found = true;
		}
		else if(vector[middle] > value)
		{
			last = middle - 1;
		}
		else
		{
			first = middle + 1;
		}
	}

        cout << fileName << ": target value";
        if(found == true)
        {
                cout << " found" << endl;
        }
        else
        {
                cout << " not found" << endl;
        }
}

		







		








	

