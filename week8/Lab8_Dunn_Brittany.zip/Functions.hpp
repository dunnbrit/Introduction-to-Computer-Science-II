/*************************************************************************
 * Program Name: Functions.hpp
 * Author: Brittany Dunn
 * Date: May 27 2018
 * Description: This is the header file for the functions.
 *************************************************************************/

#ifndef FUCNTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>
#include <fstream>
#include <vector>

void readFromFile(std::string, std::vector<int>&);
void search(std::string fileName, int value, std::vector<int>&);
std::string sort(std::vector<int>&);
void binarysearch(std::string fileName, int value, std::vector<int>&);

#endif
