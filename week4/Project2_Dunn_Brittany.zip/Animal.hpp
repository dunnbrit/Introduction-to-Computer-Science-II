/*************************************************************************
 * Program Name: Animal.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Animal.
 *************************************************************************/

#ifndef ANIMAL_HPP
#define ANIMAL_HPP

class Animal
{
	protected:
		int age;
		int cost;
		int numberOfBabies;
		int baseFoodCost = 10;
		int payoff;
		virtual void setAge(int);
		virtual void setCost();
		virtual void setNumberOfBabies();
		virtual void setBaseFoodCost();
		virtual void setPayoff();
		
	public:
		Animal();
		virtual int getCost() = 0;	
		virtual int getAge() = 0;
		void ageAnimal();
		int getFoodCost();
		int getNumberOfBabies();
		int getPayoff();
};
#endif
