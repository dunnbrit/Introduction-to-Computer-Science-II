/*************************************************************************
 * Program Name: Zoo.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the class Zoo.
 *************************************************************************/
#include <iostream>
#include <memory>
#include <cstdlib>
#include <ctime>
#include "Zoo.hpp"
#include "Animal.hpp"
#include "Turtle.hpp"
#include "Tiger.hpp"
#include "Penguin.hpp"

using std::cout;
using std::endl;
using std::rand;

//This is the constructor for Zoo. It takes 3 integers as parameters.
Zoo::Zoo(int turtles, int penguins, int tigers)
{
	//Begin the game with $100,000 in the bank
	bank = 100000;
	bonus = 0;
	//Create the zoo array for each animal
	turtleSpaces = 10;
	turtleCounter = 0;
	penguinSpaces = 10;
	penguinCounter = 0;
	tigerSpaces = 10;
	tigerCounter = 0;
	makeZoo();
	//Buy baby animals as user selected
	while(turtleCounter < turtles)
	{
		buyAnimal(TURTLE,1);
	}
	while(penguinCounter < penguins)
	{
		buyAnimal(PENGUIN,1);
	}
	while(tigerCounter < tigers)
	{
		buyAnimal(TIGER,1);
	}
}

//This function dynmatically allocates memory to create an 2D array of 
//animals to represent the animals held in the zoo
void Zoo::makeZoo()
{
	turtleZoo = new Animal*[turtleSpaces];
	penguinZoo = new Animal*[penguinSpaces];
	tigerZoo = new Animal*[tigerSpaces];

	cout << "Zoo has been built." << endl;
}

//This function adds an animal to the zoo array of the correct animal type
void Zoo::buyAnimal(int type, int age)
{
	switch(type)
	{
	case TURTLE:
	{	
		if(turtleCounter == turtleSpaces)
		{
			expandZoo(TURTLE);
		}  
		turtleZoo[turtleCounter] = new Turtle(age);
		bank -= turtleZoo[turtleCounter] -> getCost();
		cout << "You bought 1 turtle who is ";
		cout << turtleZoo[turtleCounter]->getAge() <<" days old."<<endl;
		cout << "Bank is currently at: " << bank <<endl;
		++turtleCounter;

	}
		break;
	case TIGER:
	{	
		if(tigerCounter == tigerSpaces)
		{
			expandZoo(TIGER);
		}
		tigerZoo[tigerCounter] = new Tiger(age);
		bank -= tigerZoo[tigerCounter] -> getCost();
		cout << "You bought 1 tiger who is ";
		cout << tigerZoo[tigerCounter]->getAge() <<" days old."<<endl;
		cout << "Bank is currently at: " << bank <<endl;
		++tigerCounter;
	}
		break;
	case PENGUIN:
	{
		if(penguinCounter == penguinSpaces)
		{
			expandZoo(PENGUIN);
		}
		penguinZoo[penguinCounter] = new Penguin(age);
		bank -= penguinZoo[penguinCounter] -> getCost();
		cout << "You bought 1 penguin who is ";
		cout << penguinZoo[penguinCounter]->getAge();
		cout << " days old." << endl;
		cout << "Bank is currently at: " << bank <<endl;
		++penguinCounter;
	}
		break;
	}
}

//This function doubles the size of the zoo when it reaches capcity for animals
void Zoo::expandZoo(int choice)
{
	switch(choice)
	{
	case TURTLE:
	{
		turtleSpaces *= 2;
		Animal **tempZoo = new Animal* [turtleSpaces];
		for(int i = 0; i < turtleCounter; ++i)
		{
			tempZoo[i] = new Turtle(*turtleZoo[i]);
		}
		for(int i = 0; i < turtleCounter; ++i)
		{
			delete turtleZoo[i];
		}
		delete [] turtleZoo;
		turtleZoo = tempZoo;
		cout << "Zoo expanded. " << endl;
	}
		break;
	case PENGUIN:
	{
		penguinSpaces *= 2;
		Animal **tempZoo = new Animal* [penguinSpaces];
		for(int i = 0; i < penguinCounter; ++i)
		{
			 tempZoo[i] = new Penguin(*penguinZoo[i]);
		}
		for(int i = 0; i < penguinCounter; ++i)
		{
			delete penguinZoo[i];
		}
		delete [] penguinZoo;
		penguinZoo = tempZoo;
		cout << "Zoo expanded. " << endl;
	}
		break;
	case TIGER:
	{
		tigerSpaces *= 2;
		Animal **tempZoo = new Animal* [tigerSpaces];
		for(int i = 0; i < tigerCounter; ++i)
		{
			 tempZoo[i] = new Tiger(*tigerZoo[i]);
		}
		for(int i = 0; i < tigerCounter; ++i)
 		{
			delete tigerZoo[i];
		}
		delete [] tigerZoo;
		tigerZoo = tempZoo;
		cout << "Zoo expanded. " << endl;
	}
		break;
	}
}
	
//This function ages all animals 1 day
void Zoo::ageAnimals()
{
	for(int i = 0; i < turtleCounter; ++i)
	{
		turtleZoo[i] -> ageAnimal();
		cout << "Turtle " << i << "  is now " << turtleZoo[i]->getAge();
		cout << " days old." << endl;
	}		
	for(int i = 0; i < penguinCounter; ++i)
	{
		penguinZoo[i] -> ageAnimal();
		cout << "Penguin " << i << " is now ";
		cout << penguinZoo[i]->getAge() << " days old." << endl;
	}
	for(int i = 0; i < tigerCounter; ++i)
	{
		tigerZoo[i] -> ageAnimal();
		cout << "Tiger " << i << " is now " << tigerZoo[i]->getAge();
		cout << " days old." << endl;
	}
}

//This function subtracts each animals feeding cost from the bank
void Zoo::feedAnimals()
{
	bank -= ((turtleZoo[0] -> getFoodCost()) * turtleCounter);
	cout << "Turtles feed. Bank is currently at: " << bank <<endl;
	bank -= ((penguinZoo[0] -> getFoodCost()) * penguinCounter);
	cout << "Penguins feed. Bank is currently at: " << bank <<endl;
	bank -= ((tigerZoo[0] -> getFoodCost()) * tigerCounter);
	cout << "Tigers feed. Bank is currently at: " << bank <<endl;

}

//This function chooses and excutes a random event for the day
void Zoo::randomEvent()
{
	srand(time(NULL));
	int event; 
	event = rand() % 4 + 1;
	
	switch(event)
	{
		//Sickness in zoo
		case 1:
		{
			srand(time(NULL));
			int randomAnimal; 
			randomAnimal = rand() % 3 + 1;
			
			switch(randomAnimal)
			{
				//Turtle
				case 1:
				{
					if(turtleCounter > 0)
					{
					delete turtleZoo[turtleCounter];
					--turtleCounter;
					cout << "Sick turtle has been";
					cout << " removed from zoo." << endl;
					}
					else
					{
					cout << "No sick animals to remove." <<endl;
					}
				}
					break;
				//Penguin
				case 2:
				{
					if(penguinCounter > 0)
					{
					delete penguinZoo[penguinCounter];
					--penguinCounter;
					cout << "Sick penguin has been";
					cout << " removed from zoo." << endl;
					}
					else
					{  
					cout << "No sick animals to remove." <<endl;
					}

				}
					break;
				//Tiger
				case 3:
				{
					if(tigerCounter > 0)
					{
					delete tigerZoo[tigerCounter];
					--tigerCounter;
					cout << "Sick tiger has been";
					cout << " removed from zoo." << endl;
					}
					else
					{
					cout << "No sick animals to remove."<<endl;
					}
				}
			}
		}
			break;
		//Boom in zoo attendence
		case 2:
		{
			srand(time(NULL));
			int boom;
			boom = (rand() % (500 - 250 + 1)) + 250;
			bonus = tigerCounter * boom;
			cout << "Tiger bonus day.";
			cout << " You earned $" << bonus << endl;
		}
			break;
 		//Baby animal born
 		case 3:
		{	
			srand(time(NULL));
			int randAnimal;
			randAnimal = rand() % 3 + 1;
			
			if(checkForAdult(randAnimal) == false)
			{
				if(checkForAdult(1) == true)
				{
					newBabyAnimal(TURTLE);
				}
				else if(checkForAdult(2) == true)
				{
					newBabyAnimal(PENGUIN);
				}
				else if(checkForAdult(3) == true)
				{
					newBabyAnimal(TIGER);
				}
				else
				{
					cout << "Zoo has no adult animals.";
					cout << " No babies born today." <<endl;
				}
			}
			else
			{
				switch(randAnimal)
				{
					//Turtle
					case 1:
					{
						newBabyAnimal(TURTLE);
					}
						break;

					//Penguin
					case 2:
					{
						newBabyAnimal(PENGUIN);
					}			
						break;
					//Tiger
					case 3:
					{
						newBabyAnimal(TIGER);
					}
						break;
				}
			}
		}	
			break;

		//No event
		case 4:
		{
			cout << "No event happened today." << endl;
		}
			break;
	}
}

//This function checks for adult animals
bool Zoo::checkForAdult(int animal)
{
	bool adult = false;

	switch(animal)
	{
		//Turtle
		case 1:
		{
			for(int i = 0; i < turtleCounter; ++i)
			{
				if((turtleZoo[i] -> getAge()) > 2)
				{
					adult = true;
				}	
			}
		}
			break;
		//Penguin
		case 2:
		{
			for(int i = 0; i < penguinCounter; ++i)
			{
				if((penguinZoo[i] -> getAge()) > 2)
				{
					adult = true;
				}
			}
		}
			break;
		//Tiger
		case 3:
		{
			for(int i = 0; i < tigerCounter; ++i)
			{
				if((tigerZoo[i] -> getAge()) > 2)
				{
					adult = true;
				}
			}
		}
			break;
	}
	
	return adult;
}

//This function adds a baby animal to the zoo array
void Zoo::newBabyAnimal(int animal)
{
	switch(animal)
	{
		case TURTLE:
		{
			for(int i = 0; i < turtleZoo[0] -> getNumberOfBabies(); ++i)
			{
				if(turtleCounter == turtleSpaces)
				{
					expandZoo(TURTLE);
				}		
				turtleZoo[turtleCounter] = new Turtle(0);
				++turtleCounter;
				cout << "You have 1 new baby turtle." << endl;
			}
	
			cout << "You have a total of " << turtleZoo[0] -> getNumberOfBabies();
			cout << " new baby turtles." << endl;
		}
			break;

		case PENGUIN:
		{
			for(int i = 0; i < penguinZoo[0] -> getNumberOfBabies(); ++i)
			{
				if(penguinCounter == penguinSpaces)
				{		
					expandZoo(PENGUIN);
				}
				penguinZoo[penguinCounter] = new Penguin(0);
				++penguinCounter;
				cout << "You have 1 new baby penguin" << endl;
			}
	
			cout << "You have a total of " << penguinZoo[0] -> getNumberOfBabies();
			cout << " new baby penguins." << endl;
		}
			break;
	
		case TIGER:
		{
			for(int i = 0; i < tigerZoo[0] -> getNumberOfBabies(); ++i)
			{
				if(tigerCounter == tigerSpaces)
				{
					expandZoo(TIGER);
				}
				tigerZoo[tigerCounter] = new Tiger(0);
				++tigerCounter;
				cout << "You have 1 new baby tiger." << endl;
			}	
	
			cout << "You have a total of " << tigerZoo[0] -> getNumberOfBabies();
			cout << " new baby tigers." << endl;
		}
			break;
	}
}
		
//This function calculates profit for the day and adds it to the bank
void Zoo::calculateProfit()
{
	int profit;
	profit = ((turtleZoo[0] -> getPayoff())*turtleCounter)+
		((penguinZoo[0] -> getPayoff())*penguinCounter)+
		((tigerZoo[0] -> getPayoff())*tigerCounter);
	cout << "Today's profit is $" << profit << " and today's bonus is $";
	cout << bonus << endl;
	bank +=(profit + bonus);
	bonus =0;
	cout << "Bank is currently at: " << bank << endl;
} 			

//This function returns the bank balance
int Zoo::getBankBalance()
{
	return bank;
}

//This function deletes the dynamtically allocated memory for the arrays
void Zoo::closeZoo()
{
	for(int i = 0; i < tigerCounter; ++i)
	{
		delete tigerZoo[i];
	}
	delete [] tigerZoo;

	for(int i = 0; i < penguinCounter; ++i)
	{
		delete penguinZoo[i];
	}
	delete [] penguinZoo;

	for(int i = 0; i < turtleCounter; ++i)
	{
		delete turtleZoo[i];
	}
	delete [] turtleZoo;
	
	cout << "Zoo has been closed." << endl;
}

