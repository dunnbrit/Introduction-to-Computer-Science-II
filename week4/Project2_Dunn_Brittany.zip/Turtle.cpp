/*************************************************************************
 * Program Name: Turtle.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Turtle
 *************************************************************************/
#include <iostream>
#include "Turtle.hpp"
#include "Zoo.hpp"

using std::cout;
using std::endl;

//This is the default constructor for Turtle class
Turtle::Turtle(int age)
{
	setAge(age);
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

Turtle::Turtle(Animal& animal)
{
	setAge(animal.getAge());
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

//This fucntion sets the member varible of base class
void Turtle::setAge(int a)
{
	age = a;
}

//This fucntion sets the member varible of base class
void Turtle::setCost()
{
	cost = 100;
}

//This fucntion sets the member varible of base class
void Turtle::setNumberOfBabies()
{
	numberOfBabies = 10;
}
	
//This fucntion sets the member varible of base class
void Turtle::setBaseFoodCost()
{
	baseFoodCost *= .50;
}

//This fucntion sets the member varible of base class
void Turtle::setPayoff()
{
	payoff = getCost() * .05;
}

//This function returns the cost
int Turtle::getCost()
{
	return cost;
}	

//This function returns the age
int Turtle::getAge()
{
	return age;
}
 
