/*************************************************************************
 * Program Name: Animal.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the class Animal.
 *************************************************************************/

#include <iostream>
#include "Animal.hpp"

//This is the default constructor for the Animal class
Animal::Animal()
{
	setAge(0);
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

void Animal::setAge(int a)
{
	age = a;
}


void Animal::setCost()
{
	cost = 0;
}
void Animal::setNumberOfBabies()
{
	numberOfBabies =0;
}
void Animal::setBaseFoodCost()
{
	baseFoodCost = 10;
}
void Animal::setPayoff()
{
	payoff = 0;
}

//This fuction ages the animal 1 day
void Animal::ageAnimal()
{
	age += 1;
	std::cout << "Animal aged 1 day" <<std::endl;
}

//This function returns the base cost of food
int Animal::getFoodCost()
{
	return baseFoodCost;
}

//This function returns the number of babies
int Animal::getNumberOfBabies()
{
	return numberOfBabies;
}

//This function returns the payoff
int Animal::getPayoff()
{
	return payoff;
}
