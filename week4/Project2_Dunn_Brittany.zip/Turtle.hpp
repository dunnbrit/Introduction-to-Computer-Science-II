/*************************************************************************
 * Program Name: Turtle.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Turtle
 *************************************************************************/

#ifndef TURTLE_HPP
#define TURTLE_HPP

#include "Animal.hpp"

class Turtle : public Animal
{
	private:
		void setAge(int)override;
		void setCost()override;
		void setNumberOfBabies() override;
		void setBaseFoodCost()override;
		void setPayoff() override;

	public:
		Turtle(Animal&);
		Turtle(int);
		int getCost() override;
		int getAge() override;

};
#endif
