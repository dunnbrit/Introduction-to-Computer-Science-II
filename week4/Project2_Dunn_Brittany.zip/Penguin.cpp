/*************************************************************************
 * Program Name: Penguin.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Penguin
 *************************************************************************/
#include <iostream>
#include "Penguin.hpp"

using std::cout;
using std::endl;

//This is the default constructor for Turtle class
Penguin::Penguin(int age)
{
	setAge(age);
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}


Penguin::Penguin(Animal& animal)
{
	setAge(animal.getAge());
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

//This fucntion sets the member varible of base class
void Penguin::setAge(int a)
{
	age = a;
}

//This fucntion sets the member varible of base class
void Penguin::setCost()
{
	cost = 1000;
}

//This fucntion sets the member varible of base class
void Penguin::setNumberOfBabies()
{
	numberOfBabies = 5;
}
	
//This fucntion sets the member varible of base class
void Penguin::setBaseFoodCost()
{
	baseFoodCost *= 1;
}

//This fucntion sets the member varible of base class
void Penguin::setPayoff()
{
	payoff = getCost() * .10;
}

//This function returns the cost
int Penguin::getCost()
{
	return cost;
}	

//This function returns the age
int Penguin::getAge()
{
	return age;
}
