/*************************************************************************
 * Program Name: Menu.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the Menu functions.
 *************************************************************************/
#include <iostream>
#include <string>
#include "Zoo.hpp"
using std::string;
using std::string;
using std::cout;
using std::endl;
using std::cin;

//This function displays the start menu on console
void displayAnimalMenu()
{
	cout << "Which animal would you like to buy: " << endl;
	cout << "1. Turtle" << endl;
	cout << "2. Penguin" << endl;
	cout << "3. Tiger" << endl;
	cout << "Please enter the number of your choice." << endl;
}

//This function displays the end menu on console
void displayEndMenu()
{	
	cout << "Would you like to: " << endl;
	cout << "1. Keep Playing or " << endl;
	cout << "2. End Game" << endl;
	cout << "Please enter the number of your choice." <<endl;
}

//This function takes the choice input by the user and uses a switch
//statement to determine next action
void  animalMenuChoice(int choice,Zoo& zoo)
{
	switch(choice)
	{
		case 1: 
		{
			zoo.buyAnimal(TURTLE,3);
		}	
			break;
		case 2:
		{
			zoo.buyAnimal(PENGUIN,3);
		}
			break;
		case 3:
		{
			zoo.buyAnimal(TIGER,3);
		}
			break;
	}
}

