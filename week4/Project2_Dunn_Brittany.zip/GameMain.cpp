/*************************************************************************
 * Program Name: GameMain.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This program runs a game of zoo tycoon.
 *************************************************************************/

#include <iostream>
#include <string>
#include "Zoo.hpp"
#include "Animal.hpp"
#include "Penguin.hpp"
#include "Tiger.hpp"
#include "Turtle.hpp"
#include "getInt.hpp"
#include "Menu.hpp" 

using std::cout;
using std::cin;
using std::endl;
using std::string;


int main()
{
	int turtles;
	int penguins;
	int tigers;
	string temp1;
	string temp2;

	cout << "Beginning game..." << endl;
	//Have user choose 1 or 2 animals of each type
	
	//Turtles
	cout << "Would you like to begin with";
	cout << " 1 or 2 turtles in your zoo?" <<endl;
	//Get choice
	cin >> temp1;
	//Validate it is 1 or 2
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	turtles = getInt(temp2);
	while(turtles < 1 || turtles > 2)
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		turtles = getInt(temp2);
	}
 	
	//Penguins
	cout << "Would you like to begin with";
	cout << " 1 or 2 penguins in your zoo?" <<endl;
	//Get choice
	cin.clear();
	cin >> temp1;
	//Validate it is 1 or 2
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		 temp2 = inputInvalid();
	}
	penguins = getInt(temp2);
	while(penguins < 1 || turtles > 2)
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		penguins = getInt(temp2);
	}

	//Tigers
	cout << "Would you like to begin with";
	cout << " 1 or 2 tigers in your zoo?" <<endl;
	//Get choice
	cin.clear();
	cin >> temp1;
	//Validate it is 1 or 2
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	tigers = getInt(temp2);
	while(tigers < 1 || tigers > 2)
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		tigers = getInt(temp2);
	}
	
	//Create zoo object
	Zoo myZoo(turtles, penguins, tigers);
	
	//Start Days
	int gameChoice;
	do
	{
		//Age animals a day
		myZoo.ageAnimals();
		//Feed animals for the day
		myZoo.feedAnimals();
		//Choose random event
		myZoo.randomEvent();
		//Calculate profit
		myZoo.calculateProfit();
		//Ask about buying an adult animal
		int buyAdultAnimal;
		cout << "Would you like to buy an adult animal?" << endl;
		cout << "Please enter 1 for YES or 2 for NO." <<endl;
		//Get choice
		cin >> temp1;
		//Validate it is 1 or 2
		temp2 = inputValid(temp1);
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		buyAdultAnimal = getInt(temp2);
		while(buyAdultAnimal < 1 || buyAdultAnimal > 2)
		{
			temp2 = inputInvalid();
			while(temp2 == "invalid")
			{	
				temp2 = inputInvalid();
			}
			buyAdultAnimal = getInt(temp2);
		}
		
		//If yes, ask type
		if(buyAdultAnimal == 1)
		{
			int choice;

			//Display animal menu	
			displayAnimalMenu();
			//Get user's chocie
			cin >> temp1;
			//Validate it is 1 or 2 or 3
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			choice = getInt(temp2);
			while(choice < 1 || choice > 3)
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice = getInt(temp2);
 			}	
			//Use choice with menu
			animalMenuChoice(choice, myZoo);
		}

		//See if user would like to keep playing
		displayEndMenu();
		//Get choice
		cin >> temp1;
		//Validate it is 1 or 2
		temp2 = inputValid(temp1);
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		gameChoice = getInt(temp2);
		while(gameChoice < 1 || gameChoice > 2)
		{
			temp2 = inputInvalid();
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}
			gameChoice = getInt(temp2);
		}
		if(myZoo.getBankBalance() <= 0)
		{	
			gameChoice = 2;
			cout << "Bank balance is $0. Game over." << endl;
		} 
	}
	while(gameChoice == 1);	

	myZoo.closeZoo();

	return 0;
}
