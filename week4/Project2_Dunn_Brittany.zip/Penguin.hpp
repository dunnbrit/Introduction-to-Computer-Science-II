/*************************************************************************
 * Program Name: Penguin.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Penguin
 *************************************************************************/

#ifndef PENGUIN_HPP
#define PENGUIN_HPP

#include "Animal.hpp"

class Penguin : public Animal
{
	private:
		void setAge(int)override;
		void setCost()override;
		void setNumberOfBabies() override;
		void setBaseFoodCost()override;
		void setPayoff() override;

	public:
		Penguin(Animal&);
		Penguin(int);
		int getCost() override;
		int getAge() override;
};
#endif
