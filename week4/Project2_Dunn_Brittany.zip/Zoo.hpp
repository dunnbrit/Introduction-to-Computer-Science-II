/*************************************************************************
 * Program Name: Zoo.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Zoo.
 *************************************************************************/

#ifndef ZOO_HPP
#define ZOO_HPP

#include "Animal.hpp"
#include "Turtle.hpp"
#include "Tiger.hpp"
#include "Penguin.hpp"

enum AnimalTypes {TURTLE, PENGUIN, TIGER};

class Zoo
{
	private:
		int bank;
		int bonus;
		int animalTypes;
		int animalSpaces;
		int penguinCounter;
		int turtleCounter;
		int tigerCounter;
		int turtleSpaces;
		int tigerSpaces;
		int penguinSpaces;
		Animal **turtleZoo;
		Animal **penguinZoo;
		Animal **tigerZoo;
	public:
		Zoo(int turtles, int penguins, int tigers);
		void makeZoo();
		void buyAnimal(int,int);
		void expandZoo(int);
		void ageAnimals();
		void feedAnimals();
		void randomEvent();
		bool checkForAdult(int);
		void newBabyAnimal(int);
		void calculateProfit();
		int getBankBalance();
		void closeZoo();
};
#endif
