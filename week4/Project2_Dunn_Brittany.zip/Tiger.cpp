/*************************************************************************
 * Program Name: Tiger.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Tiger
 *************************************************************************/
#include <iostream>
#include "Tiger.hpp"

using std::cout;
using std::endl;

//This is the default constructor for Turtle class
Tiger::Tiger(int age)
{
	setAge(age);
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

Tiger::Tiger(Animal& animal)
{
	setAge(animal.getAge());
	setCost();
	setNumberOfBabies();
	setBaseFoodCost();
	setPayoff();
}

//This fucntion sets the member varible of base class
void Tiger::setAge(int a)
{
	age = a;
}

//This fucntion sets the member varible of base class
void Tiger::setCost()
{
	cost = 10000;
}

//This fucntion sets the member varible of base class
void Tiger::setNumberOfBabies()
{
	numberOfBabies = 1;
}
	
//This fucntion sets the member varible of base class
void Tiger::setBaseFoodCost()
{
	baseFoodCost *= 5;
}

//This fucntion sets the member varible of base class
void Tiger::setPayoff()
{
	payoff = getCost() * .20;
}

//This function returns the cost
int Tiger::getCost()
{
	return cost;
}	

//This function returns the age
int Tiger::getAge()
{
	return age;
}

