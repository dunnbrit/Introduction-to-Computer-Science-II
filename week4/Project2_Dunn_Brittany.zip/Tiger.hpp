/*************************************************************************
 * Program Name: Tiger.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Tiger
 *************************************************************************/

#ifndef TIGER_HPP
#define TIGER_HPP

#include "Animal.hpp"

class Tiger : public Animal
{
	private:
		void setAge(int)override;
		void setCost()override;
		void setNumberOfBabies() override;
		void setBaseFoodCost()override;
		void setPayoff() override;

	public:
		Tiger(Animal&);
		Tiger(int);
		int getCost() override;
		int getAge() override;
};
#endif
