/*************************************************************************
 * Program Name: Person.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the base class Person
 *************************************************************************/

#ifndef PERSON_HPP
#define PERSON_HPP

#include <string>

class Person
{
	protected:
		std::string name;
		int age;
		void setName(std::string);
		virtual void setAge();
	public:
		Person();
		std::string getName();
		virtual void do_work(){};
		int getAge();
		virtual double getGPAorRating() {return 6.0;};
};

#endif	
