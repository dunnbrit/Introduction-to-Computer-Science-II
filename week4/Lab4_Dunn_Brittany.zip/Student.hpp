/*************************************************************************
 * Program Name: Student.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the derived Person class Student
 *************************************************************************/

#ifndef STUDENT_HPP
#define STUDENT_HPP

#include <string>
#include "Person.hpp"

class Student : public Person
{
	private:
		double GPA;
		void setAge() override;
		void setGPA();
	public:
		Student(std::string);
		void do_work() override;
		double getGPAorRating() override;
};

#endif
