/*************************************************************************
 * Program Name: Building.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class Building
 *************************************************************************/

#ifndef BUILDING_HPP
#define BUILDING_HPP

#include <string>

class Building
{
	private:
		std::string name;
		int size;
		std::string address;
	public:
		Building(std::string,int,std::string);
		std::string getName();
		std::string getAddress();
		int getSize();
};

#endif
		
