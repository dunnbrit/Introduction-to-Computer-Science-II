/*************************************************************************
 * Program Name: University.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the class University
 *************************************************************************/

#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include "University.hpp"

using std::cout;
using std::endl;
using std::vector;
using std::shared_ptr;

//This is the constructor for University
University::University(vector<shared_ptr<Person>>& p,vector<shared_ptr<Building>>& b)
{
	people = p;
	buildings = b;
}

//This function prints all the people and their information
void University::printPeople()
{
	for(int i = 0; i < people.size(); ++i)
	{
		cout << "Name: " << people[i]->getName() << endl;
		cout << "Age: " << people[i]->getAge() << endl;
		cout << people[i]->getGPAorRating() << endl;
	}
}

//This function prints all the buildings and their information
void University::printBuildings()
{
	for(int i = 0; i < buildings.size(); ++i)
	{
		cout << "Name: " << buildings[i]->getName() << endl;
		cout << "Size: " << buildings[i]->getSize() <<" sqft" << endl;
		cout << "Address: " << buildings[i]->getAddress() <<endl;
	}
}

//This function returns the vector of people
vector<shared_ptr<Person>> University::getPeople()
{
	return people;
}
