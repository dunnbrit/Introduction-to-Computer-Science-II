/*************************************************************************
 * Program Name: Person.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the base class Preson
 *************************************************************************/

#include <iostream>
#include <string>
#include "Person.hpp"

using std::string;

//This is the default constructor
Person::Person()
{
	setAge();
	setName(" ");
}

//This function sets age
void Person::setAge()
{
	age = 0;
}

//This function accepts a string parameter and uses it to set name
void Person::setName(string n)
{
	name = n;
}

//This function returns the name
string Person::getName()
{
	return name;
}

//This function returns the age
int Person::getAge()
{
	return age;
}

