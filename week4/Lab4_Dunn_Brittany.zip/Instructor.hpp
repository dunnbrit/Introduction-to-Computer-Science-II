/*************************************************************************
 * Program Name: Instructor.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the derived Person class Instructor
 *************************************************************************/

#ifndef INSTRUCTOR_HPP
#define INSTRUCTOR_HPP

#include <string>
#include "Person.hpp"

class Instructor : public Person
{
	private:
		double rating;
		void setAge() override;
		void setRating();
	public:
		Instructor(std::string);
		void do_work() override;
		double getGPAorRating() override;
};

#endif
