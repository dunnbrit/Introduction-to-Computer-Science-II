/*************************************************************************
 * Program Name: University.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the class University
 *************************************************************************/

#ifndef UNIVERSITY_HPP
#define UNIVERSITY_HPP

#include <vector>
#include <string>
#include <memory>
#include "Person.hpp"
#include "Student.hpp"
#include "Instructor.hpp"
#include "Building.hpp"

class University
{
	private:
		const std::string name = "Oregon State University";
		std::vector<std::shared_ptr<Person>> people;
		std::vector<std::shared_ptr<Building>> buildings;
	public:
		University(std::vector<std::shared_ptr<Person>>&,std::vector<std::shared_ptr<Building>>&);
		void printBuildings();
		void printPeople();
		std::vector<std::shared_ptr<Person>> getPeople();
};

#endif
