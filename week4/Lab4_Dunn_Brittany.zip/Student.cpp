/*************************************************************************
 * Program Name: Student.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the derived Person
 * class Student
 *************************************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Student.hpp"

using std::string;
using std::cout;
using std::endl;

//This is the constructor for Student
Student::Student(string name)
{
	setName(name);
	setAge();
	setGPA();
}

//This function randomly sets the age
void Student::setAge()
{
	srand(time(NULL));
	int studentAge;
	studentAge = (rand() % (50 - 18 + 1)) + 18;
	age = studentAge;
}

//This function randomly sets the GPA
void Student::setGPA()
{
	srand(time(NULL));
	double studentGPA;
	studentGPA = (4.0 - 0.0) * ((double)rand() / (double)RAND_MAX);
	GPA = studentGPA;
}

//This function outputs a message
void Student::do_work()
{
	srand(time(NULL));
	int hours;
	hours = rand() % 50 + 1;
	cout << getName() << " did " << hours << " hours of homework." <<endl;
}

//This function returns the students GPA
double Student::getGPAorRating()
{
	cout << "GPA: ";
	return GPA;
}
















