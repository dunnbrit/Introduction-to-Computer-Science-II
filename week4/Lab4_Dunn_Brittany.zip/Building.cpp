/*************************************************************************
 * Program Name: Building.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the class building.
 *************************************************************************/

#include <string>
#include "Building.hpp"

using std::string;

//This is the constructor for Building
Building::Building(string n, int s, string a)
{
	name = n;
	size = s;
	address = a;
}

//This function returns the name
string Building::getName()
{
	return name;
}

//This function returns the size
int Building::getSize()
{
	return size;
}

//This function returns the address
string Building::getAddress()
{
	return address;
}
