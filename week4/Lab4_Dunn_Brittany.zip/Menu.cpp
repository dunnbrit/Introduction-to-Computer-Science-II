/*************************************************************************
 * Program Name: Menu.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the menu functions
 *************************************************************************/
#include <iostream>
#include <string>
#include "University.hpp"
#include "Menu.hpp"
#include "getInt.hpp"

using std::string;
using std::cin;
using std::cout;
using std::endl;

//This fucntion displays the main menu
void displayMainMenu()
{
	cout << "Please choose from the menu options below: " << endl;
	cout << "1. Print information about all the buildings" << endl;
	cout << "2. Print information of everybody at the university" << endl;
	cout << "3. Choose a person to do work" << endl;
	cout << "4. Exit program" << endl;
	cout << "Please enter the number of your choice." << endl;
}

//This function takes the user's menu choice to decide next action
void mainMenuChoice(int choice, University& osu)
{
	int choice2;
	string temp1;
	string temp2;

	switch(choice)
	{
		case 1:
		{
			osu.printBuildings();
		}	break;
	
		case 2:
		{
			osu.printPeople();
		}	break;

		case 3:
		{
			cout << "Which person would you like to do work?"<<endl;
			for(int i = 0; i < (osu.getPeople()).size(); ++i)
			{
				cout << i << ": " << (osu.getPeople())[i] -> getName()<<endl;
			}
			cout << "Please enter the number of your choice."<<endl;			//Get choice
			cin >> temp1;
			//Validate choice is in range
			temp2 = inputValid(temp1);
			while(temp2 == "invalid")
			{
				temp2 = inputInvalid();
			}	
			choice2 = getInt(temp2);
			while(choice2 < 0 || choice2 > ((osu.getPeople()).size()))
			{
				temp2 = inputInvalid();
				while(temp2 == "invalid")
				{
					temp2 = inputInvalid();
				}
				choice2 = getInt(temp2);
			}
			//Have choosen person do work
			(osu.getPeople())[choice2] -> do_work();

		}	break;
	
		case 4:
			break;
	}
}
