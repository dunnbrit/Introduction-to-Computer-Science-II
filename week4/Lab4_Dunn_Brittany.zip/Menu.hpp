/*************************************************************************
 * Program Name: Menu.hpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the header file for the menu functions
 *************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include "University.hpp" 

void displayMainMenu();
void mainMenuChoice(int, University&);

#endif
