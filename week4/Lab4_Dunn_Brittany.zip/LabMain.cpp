/*************************************************************************
 * Program Name: LabMain.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This program is a simple representation of an Oregon 
 * State information system that contains information about the university.
 *************************************************************************/
#include <memory>
#include <vector>
#include <string>
#include <iostream>

#include "Person.hpp"
#include "Student.hpp"
#include "Instructor.hpp"
#include "University.hpp"
#include "getInt.hpp"
#include "Menu.hpp"

using std::cin;
using std::string;
using std::make_shared;
using std::shared_ptr;
using std::vector;

int main()
{

	//Make a vector of people
	vector<shared_ptr<Person>> people
	{
		make_shared<Student>("Mario"),
		make_shared<Instructor>("Dr.Toad")
	};

	//Make a vector of buildings
	vector<shared_ptr<Building>> buildings
	{
		make_shared<Building>("Adams Hall", 11168, "606 SW 15TH ST, CORVALLIS, OR 97331"),
		make_shared<Building>("Crop Science Building",57638, "3050 CAMPUS WAY, CORVALLIS, OR 97330")
	};

	//Create University object
	University osu(people,buildings);
	
	//Display main menu
	displayMainMenu();
	
	//Get choice
	int choice;
	string temp1;
	string temp2;	
	cin >> temp1;

	//Validate it is 1-4
	temp2 = inputValid(temp1);
	while(temp2 == "invalid")
	{
		temp2 = inputInvalid();
	}
	choice = getInt(temp2);
	while(choice < 1 || choice > 4)
	{
		temp2 = inputInvalid();
		while(temp2 == "invalid")
		{
			temp2 = inputInvalid();
		}
		choice = getInt(temp2);
	}
	
	//Use choice to determine next action
	mainMenuChoice(choice, osu);



	return 0;
}
