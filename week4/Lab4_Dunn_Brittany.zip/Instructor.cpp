/*************************************************************************
 * Program Name: Instructor.cpp
 * Author: Brittany Dunn
 * Date: April 29 2018
 * Description: This is the implementation file for the derived Person
 * class Instructor
 *************************************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Instructor.hpp"

using std::string;
using std::cout;
using std::endl;

//This is the constructor for Instructor
Instructor::Instructor(string name)
{
	setName(name);
	setAge();
	setRating();
}

//This function randomly sets the age
void Instructor::setAge()
{
	srand(time(NULL));
	int instructorAge;
	instructorAge = (rand() % (80 - 26 + 1)) + 26;
	age = instructorAge;
}

//This function randomly sets the rating
void Instructor::setRating()
{
	srand(time(NULL));
	double instructorRating;
	instructorRating = (5.0 - 0.0) * ((double)rand() / (double)RAND_MAX);
	rating = instructorRating;
}

//This function outputs a message
void Instructor::do_work()
{
	srand(time(NULL));
	int hours;
	hours = rand() % 50 + 1;
	cout << getName() << " graded papers for " << hours << " hours." <<endl;
}

//This function returns the students GPA
double Instructor::getGPAorRating()
{
	cout << "Rating: ";
	return rating;
}
















