/*************************************************************************
 * Program Name: Functions.hpp
 * Author: Brittany Dunn
 * Date: June 10 2018
 * Description: This is the header file for the fibonacci functions.
 *************************************************************************/

#ifndef FUCNTIONS_HPP
#define FUNCTIONS_HPP

int fibRecursive(int n);
int fib(int n);
 
#endif
