/*************************************************************************
 * Program Name: LabMain.cpp
 * Author: Brittany Dunn
 * Date: June 10 2018
 * Description: This program measures the time of recursive and iterative
 * fibonacci calculations.
 * I used http://www.cplusplus.com/forum/beginner/220444/ as a resource on
 * how to calculate time
 *************************************************************************/

#include <iostream>
#include <ctime>
#include "Functions.hpp"

using std::cout;
using std::cin;
using std::endl;

int main()
{
	
	cout << "Number of clock ticks per second = " << CLOCKS_PER_SEC << endl;
	cout << "Time between clock ticks = " << 1.0 / CLOCKS_PER_SEC <<endl;

	//nth fibonacci number
	int number = 2400;
	
	//Iteratively
	
	//start clock
	clock_t c_start = clock();

	//Call iterative function
	for(int i = 0; i < 100000; ++i)
	{
		fib(number);
	}
	
	//Stop clock
	clock_t c_end = clock();
	
	//Calculate seconds
	float seconds = (float)(c_end - c_start) /CLOCKS_PER_SEC;
	
	cout << number << "th fibonacci number took " << seconds;
	cout << " seconds to iteratively calculate 100,000 times." << endl;

	//Recursive

	//start clock
	c_start = clock();

	//Call recursive function
	for(int i = 0; i < 100000; ++i)
        {
                fibRecursive(number);
        }
	
	//Stop clock
	c_end = clock();

	//Calculate seconds
	seconds = (float)(c_end - c_start) /CLOCKS_PER_SEC;

        cout << number << "th fibonacci number took " << seconds;
        cout << " seconds to recursively calculate 100,000 times." << endl;




	return 0;
}
