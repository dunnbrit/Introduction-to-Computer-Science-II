/*************************************************************************
 * Program Name: Functions.cpp
 * Author: Brittany Dunn
 * Date: June 10 2018
 * Description: This is the implementation file for the fibonacci
 * functions
 *************************************************************************/

#include "Functions.hpp"
#include <iostream>


//This function returns the fibonacci number using a recursive implementation
//(Code is from textbook example page 926)
int fibRecursive(int n)
{
	if(n <= 0)
	{
		return 0;
	}
	else if(n==1)
	{
		return 1;
	}
	else
	{
		return fib(n-1) + fib(n-2);
	}
}

//This function returns the fibonacci number using iterative implementation
//(Code from website listed in lab 10 assignment)
int fib(int n)
{
	int first = 0;
	int second = 1;
	int counter = 2;

	while(counter < n)
	{
		int temp = second;
		second = first + second;
		first = temp;
		++counter;
	}
	if(n==0)
	{
		return 0;
	}
	else
	{
		return first + second;
	}
}
