/*************************************************************************
 * Program Name: startGame.hpp
 * Author: Brittany Dunn
 * Date: April 15 2018
 * Description: This is the header file for the function startGame.
 *************************************************************************/
#ifndef STARTGAME_HPP
#define STARTGAME_HPP

void startGame();

#endif
